"use client"

import { useState, useEffect } from "react"

export interface User {
  id: string
  email: string
  name: string
  role: "admin" | "user"
}

export function useAuth() {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Check if user is logged in on mount
    const savedUser = localStorage.getItem("emporio-bianchi-user")
    if (savedUser) {
      try {
        setUser(JSON.parse(savedUser))
      } catch (error) {
        console.error("Error parsing saved user:", error)
        localStorage.removeItem("emporio-bianchi-user")
      }
    }
    setLoading(false)
  }, [])

  const login = async (email: string, password: string): Promise<{ success: boolean; error?: string }> => {
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000))

    // Demo credentials
    if (email === "admin@emporiobianchi.com" && password === "admin123") {
      const adminUser: User = {
        id: "1",
        email: "admin@emporiobianchi.com",
        name: "Diego Humberto Chaves",
        role: "admin",
      }
      setUser(adminUser)
      localStorage.setItem("emporio-bianchi-user", JSON.stringify(adminUser))
      return { success: true }
    }

    return { success: false, error: "Credenziali non valide" }
  }

  const logout = () => {
    setUser(null)
    localStorage.removeItem("emporio-bianchi-user")
  }

  const isAdmin = () => {
    return user?.role === "admin"
  }

  return {
    user,
    loading,
    login,
    logout,
    isAdmin,
    isAuthenticated: !!user,
  }
}
