"use client"

import { useState, useEffect } from "react"
import type { Product } from "./products"

export interface FavoriteItem {
  product: Product
  addedAt: Date
}

export function useFavorites() {
  const [favorites, setFavorites] = useState<FavoriteItem[]>([])

  // Load favorites from localStorage on mount
  useEffect(() => {
    const savedFavorites = localStorage.getItem("emporio-bianchi-favorites")
    if (savedFavorites) {
      try {
        const parsed = JSON.parse(savedFavorites)
        setFavorites(
          parsed.map((item: any) => ({
            ...item,
            addedAt: new Date(item.addedAt),
          })),
        )
      } catch (error) {
        console.error("Error loading favorites:", error)
      }
    }
  }, [])

  // Save favorites to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem("emporio-bianchi-favorites", JSON.stringify(favorites))
  }, [favorites])

  const addToFavorites = (product: Product) => {
    setFavorites((prev) => {
      // Check if already in favorites
      if (prev.some((item) => item.product.id === product.id)) {
        return prev
      }
      return [...prev, { product, addedAt: new Date() }]
    })
  }

  const removeFromFavorites = (productId: string) => {
    setFavorites((prev) => prev.filter((item) => item.product.id !== productId))
  }

  const isFavorite = (productId: string) => {
    return favorites.some((item) => item.product.id === productId)
  }

  const clearFavorites = () => {
    setFavorites([])
  }

  return {
    favorites,
    addToFavorites,
    removeFromFavorites,
    isFavorite,
    clearFavorites,
    favoritesCount: favorites.length,
  }
}
