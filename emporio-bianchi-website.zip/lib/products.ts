export interface Product {
  id: string
  name: string
  description: string
  price: number
  category: string
  subcategory?: string
  image: string
  inStock: boolean
  featured?: boolean
  tags?: string[]
}

export const products: Product[] = [
  // Carte TCG
  {
    id: "pokemon-booster-sv",
    name: "Pokémon Booster Pack Scarlatto e Violetto",
    description: "Booster pack dell'ultima espansione Pokémon con 11 carte incluse",
    price: 4.5,
    category: "tcg",
    subcategory: "pokemon",
    image: "/placeholder.svg?height=300&width=250&text=Pokemon+Booster",
    inStock: true,
    featured: true,
    tags: ["pokemon", "booster", "nuovo"],
  },
  {
    id: "yugioh-structure-deck",
    name: "Yu-Gi-Oh! Structure Deck Albaz Strike",
    description: "Deck precostruito competitivo con 40 carte + extra deck",
    price: 12.9,
    category: "tcg",
    subcategory: "yugioh",
    image: "/placeholder.svg?height=300&width=250&text=YuGiOh+Structure",
    inStock: true,
    tags: ["yugioh", "structure", "competitivo"],
  },
  {
    id: "magic-commander-deck",
    name: "Magic Commander Deck 2024",
    description: "Deck Commander precostruito da 100 carte pronto per giocare",
    price: 45.0,
    category: "tcg",
    subcategory: "magic",
    image: "/placeholder.svg?height=300&width=250&text=Magic+Commander",
    inStock: true,
    featured: true,
    tags: ["magic", "commander", "precostruito"],
  },

  // Giocattoli
  {
    id: "lego-creator-casa",
    name: "LEGO Creator Casa Modulare",
    description: "Set LEGO Creator con 2000+ pezzi per costruire una casa dettagliata",
    price: 89.99,
    category: "giocattoli",
    subcategory: "costruzioni",
    image: "/placeholder.svg?height=300&width=250&text=LEGO+Casa",
    inStock: true,
    featured: true,
    tags: ["lego", "costruzioni", "creator"],
  },
  {
    id: "puzzle-1000-pezzi",
    name: "Puzzle Paesaggio Italiano 1000 pezzi",
    description: "Bellissimo puzzle raffigurante un paesaggio della Toscana",
    price: 15.9,
    category: "giocattoli",
    subcategory: "puzzle",
    image: "/placeholder.svg?height=300&width=250&text=Puzzle+1000",
    inStock: true,
    tags: ["puzzle", "paesaggio", "italia"],
  },

  // Giocattoli da Mare
  {
    id: "set-spiaggia-completo",
    name: "Set Spiaggia Completo con Secchiello",
    description: "Set completo con secchiello, palette, formine e annaffiatoio",
    price: 12.5,
    category: "mare",
    subcategory: "spiaggia",
    image: "/placeholder.svg?height=300&width=250&text=Set+Spiaggia",
    inStock: true,
    featured: true,
    tags: ["spiaggia", "secchiello", "estate"],
  },
  {
    id: "materassino-unicorno",
    name: "Materassino Gonfiabile Unicorno",
    description: "Materassino gonfiabile a forma di unicorno, perfetto per piscina e mare",
    price: 24.9,
    category: "mare",
    subcategory: "acqua",
    image: "/placeholder.svg?height=300&width=250&text=Materassino+Unicorno",
    inStock: true,
    featured: true,
    tags: ["materassino", "unicorno", "gonfiabile"],
  },

  // Gioielli
  {
    id: "collana-argento-cuore",
    name: "Collana in Argento con Ciondolo Cuore",
    description: "Elegante collana in argento 925 con ciondolo a forma di cuore",
    price: 35.0,
    category: "gioielli",
    subcategory: "collane",
    image: "/placeholder.svg?height=300&width=250&text=Collana+Argento",
    inStock: true,
    featured: true,
    tags: ["argento", "collana", "cuore"],
  },
  {
    id: "braccialetto-perle",
    name: "Braccialetto con Perle Colorate",
    description: "Braccialetto fashion con perle colorate, perfetto per l'estate",
    price: 18.5,
    category: "gioielli",
    subcategory: "braccialetti",
    image: "/placeholder.svg?height=300&width=250&text=Braccialetto+Perle",
    inStock: true,
    tags: ["braccialetto", "perle", "colorato"],
  },

  // Edicola
  {
    id: "zaino-scuola-spiderman",
    name: "Zaino Scuola Spider-Man",
    description: "Zaino per la scuola con stampa Spider-Man, scomparti multipli",
    price: 32.9,
    category: "edicola",
    subcategory: "zaini",
    image: "/placeholder.svg?height=300&width=250&text=Zaino+Spiderman",
    inStock: true,
    featured: true,
    tags: ["zaino", "scuola", "spiderman"],
  },
  {
    id: "set-quaderni-a4",
    name: "Set 10 Quaderni A4 Righe",
    description: "Set di 10 quaderni A4 con righe, copertina colorata",
    price: 8.5,
    category: "edicola",
    subcategory: "quaderni",
    image: "/placeholder.svg?height=300&width=250&text=Quaderni+A4",
    inStock: true,
    tags: ["quaderni", "scuola", "righe"],
  },
]

export const categories = {
  tcg: {
    name: "Carte TCG",
    description: "Trading Card Games per collezionisti e giocatori",
    subcategories: {
      pokemon: "Pokémon",
      yugioh: "Yu-Gi-Oh!",
      magic: "Magic: The Gathering",
      other: "Altre TCG",
    },
  },
  giocattoli: {
    name: "Giocattoli",
    description: "Giochi e giocattoli per bambini di tutte le età",
    subcategories: {
      costruzioni: "Costruzioni",
      puzzle: "Puzzle",
      educativi: "Giochi Educativi",
      action: "Action Figures",
      tavolo: "Giochi da Tavolo",
    },
  },
  mare: {
    name: "Giocattoli da Mare",
    description: "Tutto per il divertimento al mare e in piscina",
    subcategories: {
      spiaggia: "Giochi da Spiaggia",
      acqua: "Giochi d'Acqua",
      sport: "Sport Acquatici",
      accessori: "Accessori Mare",
    },
  },
  gioielli: {
    name: "Gioielli e Bijoux",
    description: "Accessori e gioielli per ogni occasione",
    subcategories: {
      collane: "Collane",
      braccialetti: "Braccialetti",
      orecchini: "Orecchini",
      anelli: "Anelli",
      orologi: "Orologi",
    },
  },
  edicola: {
    name: "Edicola",
    description: "Materiale scolastico, cancelleria e servizi",
    subcategories: {
      zaini: "Zaini e Cartelle",
      quaderni: "Quaderni e Diari",
      cancelleria: "Cancelleria",
      libri: "Libri Scolastici",
    },
  },
  regali: {
    name: "Idee Regalo",
    description: "Regali speciali per ogni occasione",
    subcategories: {
      personalizzati: "Regali Personalizzati",
      collezioni: "Collezioni Esclusive",
      gadget: "Gadget Unici",
    },
  },
}

export function getProductsByCategory(category: string): Product[] {
  return products.filter((product) => product.category === category)
}

export function getFeaturedProducts(): Product[] {
  return products.filter((product) => product.featured)
}

export function getProductById(id: string): Product | undefined {
  return products.find((product) => product.id === id)
}

export function searchProducts(query: string): Product[] {
  const lowercaseQuery = query.toLowerCase()
  return products.filter(
    (product) =>
      product.name.toLowerCase().includes(lowercaseQuery) ||
      product.description.toLowerCase().includes(lowercaseQuery) ||
      product.tags?.some((tag) => tag.toLowerCase().includes(lowercaseQuery)),
  )
}
