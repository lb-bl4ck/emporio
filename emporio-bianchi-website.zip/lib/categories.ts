"use client"

import { useState, useEffect } from "react"

export interface Category {
  id: string
  key: string
  name: string
  description: string
  icon: string
  color: string
  subcategories: Record<string, string>
  createdAt: Date
  updatedAt: Date
}

export interface SubCategory {
  key: string
  name: string
}

// Default categories
const defaultCategories: Category[] = [
  {
    id: "tcg",
    key: "tcg",
    name: "Carte TCG",
    description: "Trading Card Games per collezionisti e giocatori",
    icon: "Gamepad2",
    color: "blue",
    subcategories: {
      pokemon: "Pokémon",
      yugioh: "Yu-Gi-Oh!",
      magic: "Magic: The Gathering",
      other: "Altre TCG",
    },
    createdAt: new Date("2024-01-01"),
    updatedAt: new Date("2024-01-01"),
  },
  {
    id: "giocattoli",
    key: "giocattoli",
    name: "Giocattoli",
    description: "Giochi e giocattoli per bambini di tutte le età",
    icon: "Sparkles",
    color: "green",
    subcategories: {
      costruzioni: "Costruzioni",
      puzzle: "Puzzle",
      educativi: "Giochi Educativi",
      action: "Action Figures",
      tavolo: "Giochi da Tavolo",
    },
    createdAt: new Date("2024-01-01"),
    updatedAt: new Date("2024-01-01"),
  },
  {
    id: "mare",
    key: "mare",
    name: "Giocattoli da Mare",
    description: "Tutto per il divertimento al mare e in piscina",
    icon: "Waves",
    color: "cyan",
    subcategories: {
      spiaggia: "Giochi da Spiaggia",
      acqua: "Giochi d'Acqua",
      sport: "Sport Acquatici",
      accessori: "Accessori Mare",
    },
    createdAt: new Date("2024-01-01"),
    updatedAt: new Date("2024-01-01"),
  },
  {
    id: "gioielli",
    key: "gioielli",
    name: "Gioielli e Bijoux",
    description: "Accessori e gioielli per ogni occasione",
    icon: "Gem",
    color: "pink",
    subcategories: {
      collane: "Collane",
      braccialetti: "Braccialetti",
      orecchini: "Orecchini",
      anelli: "Anelli",
      orologi: "Orologi",
    },
    createdAt: new Date("2024-01-01"),
    updatedAt: new Date("2024-01-01"),
  },
  {
    id: "edicola",
    key: "edicola",
    name: "Edicola",
    description: "Materiale scolastico, cancelleria e servizi",
    icon: "BookOpen",
    color: "red",
    subcategories: {
      zaini: "Zaini e Cartelle",
      quaderni: "Quaderni e Diari",
      cancelleria: "Cancelleria",
      libri: "Libri Scolastici",
    },
    createdAt: new Date("2024-01-01"),
    updatedAt: new Date("2024-01-01"),
  },
  {
    id: "regali",
    key: "regali",
    name: "Idee Regalo",
    description: "Regali speciali per ogni occasione",
    icon: "Gift",
    color: "orange",
    subcategories: {
      personalizzati: "Regali Personalizzati",
      collezioni: "Collezioni Esclusive",
      gadget: "Gadget Unici",
    },
    createdAt: new Date("2024-01-01"),
    updatedAt: new Date("2024-01-01"),
  },
]

export function useCategories() {
  const [categories, setCategories] = useState<Category[]>([])
  const [loading, setLoading] = useState(true)

  // Load categories from localStorage on mount
  useEffect(() => {
    const savedCategories = localStorage.getItem("emporio-bianchi-categories")
    if (savedCategories) {
      try {
        const parsed = JSON.parse(savedCategories)
        setCategories(
          parsed.map((cat: any) => ({
            ...cat,
            createdAt: new Date(cat.createdAt),
            updatedAt: new Date(cat.updatedAt),
          })),
        )
      } catch (error) {
        console.error("Error loading categories:", error)
        setCategories(defaultCategories)
      }
    } else {
      setCategories(defaultCategories)
    }
    setLoading(false)
  }, [])

  // Save categories to localStorage whenever it changes
  useEffect(() => {
    if (!loading) {
      localStorage.setItem("emporio-bianchi-categories", JSON.stringify(categories))
    }
  }, [categories, loading])

  const addCategory = (categoryData: Omit<Category, "id" | "createdAt" | "updatedAt">) => {
    const newCategory: Category = {
      ...categoryData,
      id: `cat-${Date.now()}`,
      createdAt: new Date(),
      updatedAt: new Date(),
    }
    setCategories((prev) => [...prev, newCategory])
    return newCategory
  }

  const updateCategory = (id: string, updates: Partial<Category>) => {
    setCategories((prev) =>
      prev.map((cat) =>
        cat.id === id
          ? {
              ...cat,
              ...updates,
              updatedAt: new Date(),
            }
          : cat,
      ),
    )
  }

  const deleteCategory = (id: string) => {
    setCategories((prev) => prev.filter((cat) => cat.id !== id))
  }

  const getCategoryByKey = (key: string) => {
    return categories.find((cat) => cat.key === key)
  }

  const getCategoryById = (id: string) => {
    return categories.find((cat) => cat.id === id)
  }

  // Convert to the format expected by existing code
  const getCategoriesForProducts = () => {
    const result: Record<string, any> = {}
    categories.forEach((cat) => {
      result[cat.key] = {
        name: cat.name,
        description: cat.description,
        subcategories: cat.subcategories,
      }
    })
    return result
  }

  return {
    categories,
    loading,
    addCategory,
    updateCategory,
    deleteCategory,
    getCategoryByKey,
    getCategoryById,
    getCategoriesForProducts,
    categoriesCount: categories.length,
  }
}
