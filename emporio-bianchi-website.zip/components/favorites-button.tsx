"use client"

import { Button } from "@/components/ui/button"
import { Heart } from "lucide-react"
import Link from "next/link"
import { useFavoritesContext } from "./favorites-provider"

export function FavoritesButton() {
  const { favoritesCount } = useFavoritesContext()

  return (
    <Button variant="ghost" size="sm" className="relative" asChild>
      <Link href="/preferiti">
        <Heart className="w-5 h-5" />
        {favoritesCount > 0 && (
          <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
            {favoritesCount > 99 ? "99+" : favoritesCount}
          </span>
        )}
        <span className="sr-only">Preferiti ({favoritesCount})</span>
      </Link>
    </Button>
  )
}
