"use client"

import type React from "react"
import { createContext, useContext } from "react"
import { useCategories } from "@/lib/categories"
import type { Category } from "@/lib/categories"

interface CategoriesContextType {
  categories: Category[]
  loading: boolean
  addCategory: (categoryData: Omit<Category, "id" | "createdAt" | "updatedAt">) => Category
  updateCategory: (id: string, updates: Partial<Category>) => void
  deleteCategory: (id: string) => void
  getCategoryByKey: (key: string) => Category | undefined
  getCategoryById: (id: string) => Category | undefined
  getCategoriesForProducts: () => Record<string, any>
  categoriesCount: number
}

const CategoriesContext = createContext<CategoriesContextType | undefined>(undefined)

export function CategoriesProvider({ children }: { children: React.ReactNode }) {
  const categoriesData = useCategories()

  return <CategoriesContext.Provider value={categoriesData}>{children}</CategoriesContext.Provider>
}

export function useCategoriesContext() {
  const context = useContext(CategoriesContext)
  if (context === undefined) {
    throw new Error("useCategoriesContext must be used within a CategoriesProvider")
  }
  return context
}
