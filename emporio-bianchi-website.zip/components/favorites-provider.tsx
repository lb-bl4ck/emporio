"use client"

import type React from "react"
import { createContext, useContext } from "react"
import { useFavorites } from "@/lib/favorites"
import type { Product } from "@/lib/products"

interface FavoritesContextType {
  favorites: Array<{ product: Product; addedAt: Date }>
  addToFavorites: (product: Product) => void
  removeFromFavorites: (productId: string) => void
  isFavorite: (productId: string) => boolean
  clearFavorites: () => void
  favoritesCount: number
}

const FavoritesContext = createContext<FavoritesContextType | undefined>(undefined)

export function FavoritesProvider({ children }: { children: React.ReactNode }) {
  const favoritesData = useFavorites()

  return <FavoritesContext.Provider value={favoritesData}>{children}</FavoritesContext.Provider>
}

export function useFavoritesContext() {
  const context = useContext(FavoritesContext)
  if (context === undefined) {
    throw new Error("useFavoritesContext must be used within a FavoritesProvider")
  }
  return context
}
