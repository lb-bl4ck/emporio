import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Eye } from "lucide-react"
import Image from "next/image"
import Link from "next/link"
import type { Product } from "@/lib/products"

interface ProductCardProps {
  product: Product
  showCategory?: boolean
}

export function ProductCard({ product, showCategory = false }: ProductCardProps) {
  return (
    <Card className="hover:shadow-lg transition-shadow group h-full flex flex-col">
      <CardHeader className="p-4 flex-shrink-0">
        <div className="relative overflow-hidden rounded-lg">
          <Image
            src={product.image || "/placeholder.svg"}
            alt={product.name}
            width={250}
            height={300}
            className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
          />
          {product.featured && <Badge className="absolute top-2 left-2 bg-red-500 text-white">In Evidenza</Badge>}
          {!product.inStock && <Badge className="absolute top-2 right-2 bg-gray-500 text-white">Esaurito</Badge>}
        </div>
      </CardHeader>
      <CardContent className="p-4 flex flex-col flex-1 min-h-0">
        <div className="flex-1 space-y-2 mb-4">
          {showCategory && (
            <Badge variant="outline" className="text-xs">
              {product.category.toUpperCase()}
            </Badge>
          )}
          <CardTitle className="text-lg line-clamp-2 min-h-[3.5rem]">{product.name}</CardTitle>
          <CardDescription className="text-sm line-clamp-3 min-h-[4.5rem]">{product.description}</CardDescription>
        </div>
        <div className="flex-shrink-0 space-y-3">
          <div className="text-center">
            <span className="text-2xl font-bold text-blue-600">€{product.price.toFixed(2)}</span>
          </div>
          <div className="flex flex-col gap-2">
            <Button size="sm" variant="outline" className="w-full bg-transparent" asChild>
              <Link href={`/prodotto/${product.id}`}>
                <Eye className="w-4 h-4 mr-1" />
                Vedi Dettagli
              </Link>
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
