"use client"

import type React from "react"
import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { useAuthContext } from "./auth-provider"
import { Card, CardContent } from "@/components/ui/card"
import { Loader2 } from "lucide-react"

interface ProtectedRouteProps {
  children: React.ReactNode
  requireAdmin?: boolean
}

export function ProtectedRoute({ children, requireAdmin = false }: ProtectedRouteProps) {
  const { user, loading, isAdmin } = useAuthContext()
  const router = useRouter()

  useEffect(() => {
    if (!loading) {
      if (!user) {
        router.push("/admin/login")
        return
      }
      if (requireAdmin && !isAdmin()) {
        router.push("/")
        return
      }
    }
  }, [user, loading, isAdmin, router, requireAdmin])

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="w-96">
          <CardContent className="flex items-center justify-center p-8">
            <Loader2 className="w-8 h-8 animate-spin mr-3" />
            <span>Caricamento...</span>
          </CardContent>
        </Card>
      </div>
    )
  }

  if (!user || (requireAdmin && !isAdmin())) {
    return null
  }

  return <>{children}</>
}
