"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { products, categories } from "@/lib/products"
import { Plus, Edit, Trash2, Search, Filter, Eye, ArrowLeft } from "lucide-react"
import Link from "next/link"
import { ProtectedRoute } from "@/components/protected-route"

function ProductsManagement() {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedCategory, setSelectedCategory] = useState<string>("all")
  const [selectedStatus, setSelectedStatus] = useState<string>("all")

  const filteredProducts = products.filter((product) => {
    const matchesSearch =
      product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      product.description.toLowerCase().includes(searchTerm.toLowerCase())

    const matchesCategory = selectedCategory === "all" || product.category === selectedCategory

    const matchesStatus =
      selectedStatus === "all" ||
      (selectedStatus === "inStock" && product.inStock) ||
      (selectedStatus === "outOfStock" && !product.inStock) ||
      (selectedStatus === "featured" && product.featured)

    return matchesSearch && matchesCategory && matchesStatus
  })

  const handleDelete = (productId: string) => {
    if (confirm("Sei sicuro di voler eliminare questo prodotto?")) {
      console.log("Eliminazione prodotto:", productId)
      // In una vera applicazione, qui faresti la chiamata API per eliminare
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="sm" asChild>
                <Link href="/admin">
                  <ArrowLeft className="w-4 h-4 mr-1" />
                  Dashboard
                </Link>
              </Button>
              <div>
                <h1 className="text-2xl font-bold">Gestione Prodotti</h1>
                <p className="text-gray-600">{filteredProducts.length} prodotti trovati</p>
              </div>
            </div>
            <Button asChild>
              <Link href="/admin/prodotti/nuovo">
                <Plus className="w-4 h-4 mr-2" />
                Nuovo Prodotto
              </Link>
            </Button>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* Filters */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Filter className="w-5 h-5" />
              Filtri
            </CardTitle>
            <CardDescription>Filtra e cerca i prodotti nel catalogo</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-4 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Cerca</label>
                <div className="relative">
                  <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                  <Input
                    placeholder="Nome o descrizione..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Categoria</label>
                <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Tutte le categorie</SelectItem>
                    {Object.entries(categories).map(([key, category]) => (
                      <SelectItem key={key} value={key}>
                        {category.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Stato</label>
                <Select value={selectedStatus} onValueChange={setSelectedStatus}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Tutti</SelectItem>
                    <SelectItem value="inStock">Disponibili</SelectItem>
                    <SelectItem value="outOfStock">Esauriti</SelectItem>
                    <SelectItem value="featured">In Evidenza</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Azioni</label>
                <Button
                  variant="outline"
                  className="w-full bg-transparent"
                  onClick={() => {
                    setSearchTerm("")
                    setSelectedCategory("all")
                    setSelectedStatus("all")
                  }}
                >
                  Pulisci Filtri
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Products List */}
        <Card>
          <CardHeader>
            <CardTitle>Prodotti ({filteredProducts.length})</CardTitle>
            <CardDescription>Gestisci tutti i prodotti del catalogo</CardDescription>
          </CardHeader>
          <CardContent>
            {filteredProducts.length === 0 ? (
              <div className="text-center py-12">
                <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Search className="w-8 h-8 text-gray-400" />
                </div>
                <h3 className="text-lg font-semibold mb-2">Nessun prodotto trovato</h3>
                <p className="text-gray-600 mb-4">Prova a modificare i filtri di ricerca</p>
                <Button asChild>
                  <Link href="/admin/prodotti/nuovo">
                    <Plus className="w-4 h-4 mr-2" />
                    Aggiungi Primo Prodotto
                  </Link>
                </Button>
              </div>
            ) : (
              <div className="space-y-4">
                {filteredProducts.map((product) => (
                  <div
                    key={product.id}
                    className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 transition-colors"
                  >
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="font-semibold text-lg">{product.name}</h3>
                        {product.featured && <Badge className="bg-red-500 text-white text-xs">Featured</Badge>}
                        {!product.inStock && (
                          <Badge variant="secondary" className="text-xs">
                            Esaurito
                          </Badge>
                        )}
                      </div>
                      <p className="text-sm text-gray-600 line-clamp-2 mb-2">{product.description}</p>
                      <div className="flex items-center gap-4">
                        <span className="font-bold text-blue-600 text-lg">€{product.price.toFixed(2)}</span>
                        <Badge variant="outline" className="text-xs">
                          {categories[product.category as keyof typeof categories]?.name}
                        </Badge>
                        {product.subcategory && (
                          <Badge variant="outline" className="text-xs">
                            {
                              categories[product.category as keyof typeof categories]?.subcategories[
                                product.subcategory
                              ]
                            }
                          </Badge>
                        )}
                        <span className="text-xs text-gray-500">ID: {product.id}</span>
                      </div>
                      {product.tags && product.tags.length > 0 && (
                        <div className="flex flex-wrap gap-1 mt-2">
                          {product.tags.slice(0, 3).map((tag) => (
                            <Badge key={tag} variant="secondary" className="text-xs">
                              {tag}
                            </Badge>
                          ))}
                          {product.tags.length > 3 && (
                            <Badge variant="secondary" className="text-xs">
                              +{product.tags.length - 3}
                            </Badge>
                          )}
                        </div>
                      )}
                    </div>
                    <div className="flex gap-2 ml-4">
                      <Button size="sm" variant="outline" asChild>
                        <Link href={`/prodotto/${product.id}`}>
                          <Eye className="w-4 h-4" />
                        </Link>
                      </Button>
                      <Button size="sm" variant="outline" asChild>
                        <Link href={`/admin/prodotti/modifica/${product.id}`}>
                          <Edit className="w-4 h-4" />
                        </Link>
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        className="text-red-600 hover:text-red-700 hover:bg-red-50 bg-transparent"
                        onClick={() => handleDelete(product.id)}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

export default function ProductsPage() {
  return (
    <ProtectedRoute requireAdmin>
      <ProductsManagement />
    </ProtectedRoute>
  )
}
