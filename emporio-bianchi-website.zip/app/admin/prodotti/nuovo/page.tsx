"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { Badge } from "@/components/ui/badge"
import { useCategoriesContext } from "@/components/categories-provider"
import type { Product } from "@/lib/products"
import { Plus, Save, ArrowLeft, X, Loader2 } from "lucide-react"
import Link from "next/link"
import { ProtectedRoute } from "@/components/protected-route"

function NewProductForm() {
  const router = useRouter()
  const { categories } = useCategoriesContext()
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState(false)
  const [formData, setFormData] = useState<Partial<Product>>({
    name: "",
    description: "",
    price: 0,
    category: "",
    subcategory: "",
    image: "",
    inStock: true,
    featured: false,
    tags: [],
  })
  const [currentTag, setCurrentTag] = useState("")

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1500))

    // Generate ID
    const newProduct: Product = {
      ...formData,
      id: `product-${Date.now()}`,
      name: formData.name || "",
      description: formData.description || "",
      price: formData.price || 0,
      category: formData.category || "",
      image: formData.image || "/placeholder.svg?height=300&width=250&text=Nuovo+Prodotto",
      inStock: formData.inStock ?? true,
      featured: formData.featured ?? false,
      tags: formData.tags || [],
    }

    console.log("Nuovo prodotto creato:", newProduct)
    setSuccess(true)
    setLoading(false)

    // Redirect after success
    setTimeout(() => {
      router.push("/admin/prodotti")
    }, 2000)
  }

  const addTag = () => {
    if (currentTag.trim() && !formData.tags?.includes(currentTag.trim())) {
      setFormData({
        ...formData,
        tags: [...(formData.tags || []), currentTag.trim()],
      })
      setCurrentTag("")
    }
  }

  const removeTag = (tagToRemove: string) => {
    setFormData({
      ...formData,
      tags: formData.tags?.filter((tag) => tag !== tagToRemove) || [],
    })
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      e.preventDefault()
      addTag()
    }
  }

  const selectedCategory = categories.find((cat) => cat.key === formData.category)

  if (success) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardContent className="text-center p-8">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Save className="w-8 h-8 text-green-600" />
            </div>
            <h2 className="text-2xl font-bold mb-2">Prodotto Creato!</h2>
            <p className="text-gray-600 mb-6">Il nuovo prodotto è stato aggiunto con successo al catalogo.</p>
            <Button asChild>
              <Link href="/admin/prodotti">Torna alla Gestione Prodotti</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="sm" asChild>
                <Link href="/admin/prodotti">
                  <ArrowLeft className="w-4 h-4 mr-1" />
                  Torna ai Prodotti
                </Link>
              </Button>
              <div>
                <h1 className="text-2xl font-bold">Nuovo Prodotto</h1>
                <p className="text-gray-600">Aggiungi un nuovo prodotto al catalogo</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <form onSubmit={handleSubmit} className="space-y-8">
            {/* Basic Information */}
            <Card>
              <CardHeader>
                <CardTitle>Informazioni Base</CardTitle>
                <CardDescription>Inserisci le informazioni principali del prodotto</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="name">Nome Prodotto *</Label>
                    <Input
                      id="name"
                      value={formData.name || ""}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      placeholder="Es. Pokémon Booster Pack Scarlatto e Violetto"
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="price">Prezzo (€) *</Label>
                    <Input
                      id="price"
                      type="number"
                      step="0.01"
                      min="0"
                      value={formData.price || 0}
                      onChange={(e) => setFormData({ ...formData, price: Number.parseFloat(e.target.value) })}
                      placeholder="0.00"
                      required
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">Descrizione *</Label>
                  <Textarea
                    id="description"
                    value={formData.description || ""}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    placeholder="Descrivi il prodotto in dettaglio..."
                    rows={4}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="image">URL Immagine</Label>
                  <Input
                    id="image"
                    value={formData.image || ""}
                    onChange={(e) => setFormData({ ...formData, image: e.target.value })}
                    placeholder="/placeholder.svg?height=300&width=250&text=Prodotto"
                  />
                  <p className="text-sm text-gray-500">Lascia vuoto per usare un'immagine placeholder predefinita</p>
                </div>
              </CardContent>
            </Card>

            {/* Category */}
            <Card>
              <CardHeader>
                <CardTitle>Categoria</CardTitle>
                <CardDescription>Seleziona la categoria e sottocategoria del prodotto</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="category">Categoria *</Label>
                    <Select
                      value={formData.category || ""}
                      onValueChange={(value) => setFormData({ ...formData, category: value, subcategory: "" })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Seleziona categoria" />
                      </SelectTrigger>
                      <SelectContent>
                        {categories.map((category) => (
                          <SelectItem key={category.key} value={category.key}>
                            {category.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {formData.category && selectedCategory && (
                    <div className="space-y-2">
                      <Label htmlFor="subcategory">Sottocategoria</Label>
                      <Select
                        value={formData.subcategory || ""}
                        onValueChange={(value) => setFormData({ ...formData, subcategory: value })}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Seleziona sottocategoria" />
                        </SelectTrigger>
                        <SelectContent>
                          {Object.entries(selectedCategory.subcategories).map(([key, name]) => (
                            <SelectItem key={key} value={key}>
                              {name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Tags */}
            <Card>
              <CardHeader>
                <CardTitle>Tags</CardTitle>
                <CardDescription>Aggiungi tag per migliorare la ricerca del prodotto</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex gap-2">
                  <Input
                    value={currentTag}
                    onChange={(e) => setCurrentTag(e.target.value)}
                    onKeyPress={handleKeyPress}
                    placeholder="Aggiungi un tag..."
                  />
                  <Button type="button" onClick={addTag} disabled={!currentTag.trim()}>
                    <Plus className="w-4 h-4" />
                  </Button>
                </div>

                {formData.tags && formData.tags.length > 0 && (
                  <div className="flex flex-wrap gap-2">
                    {formData.tags.map((tag) => (
                      <Badge key={tag} variant="secondary" className="flex items-center gap-1">
                        {tag}
                        <button type="button" onClick={() => removeTag(tag)} className="ml-1 hover:text-red-500">
                          <X className="w-3 h-3" />
                        </button>
                      </Badge>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Settings */}
            <Card>
              <CardHeader>
                <CardTitle>Impostazioni</CardTitle>
                <CardDescription>Configura disponibilità e visibilità del prodotto</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="inStock">Disponibile</Label>
                    <p className="text-sm text-gray-500">Il prodotto è attualmente disponibile in negozio</p>
                  </div>
                  <Switch
                    id="inStock"
                    checked={formData.inStock || false}
                    onCheckedChange={(checked) => setFormData({ ...formData, inStock: checked })}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="featured">In Evidenza</Label>
                    <p className="text-sm text-gray-500">Mostra questo prodotto nella sezione "In Evidenza"</p>
                  </div>
                  <Switch
                    id="featured"
                    checked={formData.featured || false}
                    onCheckedChange={(checked) => setFormData({ ...formData, featured: checked })}
                  />
                </div>
              </CardContent>
            </Card>

            {/* Actions */}
            <div className="flex gap-4 justify-end">
              <Button type="button" variant="outline" asChild>
                <Link href="/admin/prodotti">Annulla</Link>
              </Button>
              <Button type="submit" disabled={loading}>
                {loading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Creazione in corso...
                  </>
                ) : (
                  <>
                    <Save className="w-4 h-4 mr-2" />
                    Crea Prodotto
                  </>
                )}
              </Button>
            </div>
          </form>
        </div>
      </div>
    </div>
  )
}

export default function NewProductPage() {
  return (
    <ProtectedRoute requireAdmin>
      <NewProductForm />
    </ProtectedRoute>
  )
}
