"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Plus, Edit, Trash2, Search, ArrowLeft, Folder } from "lucide-react"
import Link from "next/link"
import { ProtectedRoute } from "@/components/protected-route"
import { useCategoriesContext } from "@/components/categories-provider"

const iconMap: Record<string, string> = {
  Gamepad2: "🎮",
  Sparkles: "✨",
  Gift: "🎁",
  BookOpen: "📚",
  Waves: "🌊",
  Gem: "💎",
  Heart: "❤️",
  Star: "⭐",
  Zap: "⚡",
  Sun: "☀️",
  Moon: "🌙",
  Coffee: "☕",
  Music: "🎵",
  Camera: "📷",
  Palette: "🎨",
}

const colorMap: Record<string, string> = {
  blue: "bg-blue-100 text-blue-800 border-blue-200",
  green: "bg-green-100 text-green-800 border-green-200",
  red: "bg-red-100 text-red-800 border-red-200",
  orange: "bg-orange-100 text-orange-800 border-orange-200",
  purple: "bg-purple-100 text-purple-800 border-purple-200",
  pink: "bg-pink-100 text-pink-800 border-pink-200",
  cyan: "bg-cyan-100 text-cyan-800 border-cyan-200",
  yellow: "bg-yellow-100 text-yellow-800 border-yellow-200",
  gray: "bg-gray-100 text-gray-800 border-gray-200",
}

function CategoriesManagement() {
  const { categories, deleteCategory } = useCategoriesContext()
  const [searchTerm, setSearchTerm] = useState("")

  const filteredCategories = categories.filter(
    (category) =>
      category.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      category.description.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const handleDelete = (categoryId: string, categoryName: string) => {
    if (
      confirm(`Sei sicuro di voler eliminare la categoria "${categoryName}"? Questa azione non può essere annullata.`)
    ) {
      deleteCategory(categoryId)
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="sm" asChild>
                <Link href="/admin">
                  <ArrowLeft className="w-4 h-4 mr-1" />
                  Dashboard
                </Link>
              </Button>
              <div>
                <h1 className="text-2xl font-bold">Gestione Categorie</h1>
                <p className="text-gray-600">{filteredCategories.length} categorie trovate</p>
              </div>
            </div>
            <Button asChild>
              <Link href="/admin/categorie/nuova">
                <Plus className="w-4 h-4 mr-2" />
                Nuova Categoria
              </Link>
            </Button>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* Search */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Search className="w-5 h-5" />
              Cerca Categorie
            </CardTitle>
            <CardDescription>Trova e gestisci le categorie del catalogo</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="relative max-w-md">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Nome o descrizione..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
          </CardContent>
        </Card>

        {/* Categories Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredCategories.map((category) => (
            <Card key={category.id} className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-12 h-12 rounded-full flex items-center justify-center ${colorMap[category.color] || colorMap.gray}`}
                    >
                      <span className="text-2xl">{iconMap[category.icon] || "📁"}</span>
                    </div>
                    <div>
                      <CardTitle className="text-xl">{category.name}</CardTitle>
                      <Badge variant="outline" className="text-xs mt-1">
                        {category.key}
                      </Badge>
                    </div>
                  </div>
                  <div className="flex gap-1">
                    <Button size="sm" variant="outline" asChild>
                      <Link href={`/admin/categorie/modifica/${category.id}`}>
                        <Edit className="w-4 h-4" />
                      </Link>
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      className="text-red-600 hover:text-red-700 hover:bg-red-50 bg-transparent"
                      onClick={() => handleDelete(category.id, category.name)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 mb-4">{category.description}</p>

                <div className="space-y-3">
                  <div className="flex items-center justify-between text-sm">
                    <span className="font-medium">Sottocategorie:</span>
                    <Badge variant="secondary">{Object.keys(category.subcategories).length}</Badge>
                  </div>

                  {Object.keys(category.subcategories).length > 0 && (
                    <div className="space-y-2">
                      <div className="flex flex-wrap gap-1">
                        {Object.entries(category.subcategories)
                          .slice(0, 3)
                          .map(([key, name]) => (
                            <Badge key={key} variant="outline" className="text-xs">
                              {name}
                            </Badge>
                          ))}
                        {Object.keys(category.subcategories).length > 3 && (
                          <Badge variant="outline" className="text-xs">
                            +{Object.keys(category.subcategories).length - 3}
                          </Badge>
                        )}
                      </div>
                    </div>
                  )}

                  <div className="pt-2 border-t text-xs text-gray-500">
                    <div className="flex justify-between">
                      <span>Creata: {category.createdAt.toLocaleDateString("it-IT")}</span>
                      <span>Aggiornata: {category.updatedAt.toLocaleDateString("it-IT")}</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredCategories.length === 0 && (
          <Card className="text-center py-12">
            <CardContent>
              <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Folder className="w-8 h-8 text-gray-400" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Nessuna categoria trovata</h3>
              <p className="text-gray-600 mb-4">
                {searchTerm ? "Prova a modificare i termini di ricerca" : "Inizia creando la tua prima categoria"}
              </p>
              <Button asChild>
                <Link href="/admin/categorie/nuova">
                  <Plus className="w-4 h-4 mr-2" />
                  Crea Prima Categoria
                </Link>
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}

export default function CategoriesPage() {
  return (
    <ProtectedRoute requireAdmin>
      <CategoriesManagement />
    </ProtectedRoute>
  )
}
