"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Plus, Save, ArrowLeft, X, Loader2 } from "lucide-react"
import Link from "next/link"
import { ProtectedRoute } from "@/components/protected-route"
import { useCategoriesContext } from "@/components/categories-provider"
import type { Category } from "@/lib/categories"

const availableIcons = [
  { key: "Gamepad2", name: "Gaming", emoji: "🎮" },
  { key: "Sparkles", name: "Giocattoli", emoji: "✨" },
  { key: "Gift", name: "Regali", emoji: "🎁" },
  { key: "BookOpen", name: "Libri", emoji: "📚" },
  { key: "Waves", name: "Mare", emoji: "🌊" },
  { key: "Gem", name: "Gioielli", emoji: "💎" },
  { key: "Heart", name: "Amore", emoji: "❤️" },
  { key: "Star", name: "Stelle", emoji: "⭐" },
  { key: "Zap", name: "Energia", emoji: "⚡" },
  { key: "Sun", name: "Sole", emoji: "☀️" },
  { key: "Moon", name: "Luna", emoji: "🌙" },
  { key: "Coffee", name: "Caffè", emoji: "☕" },
  { key: "Music", name: "Musica", emoji: "🎵" },
  { key: "Camera", name: "Foto", emoji: "📷" },
  { key: "Palette", name: "Arte", emoji: "🎨" },
]

const availableColors = [
  { key: "blue", name: "Blu", class: "bg-blue-500" },
  { key: "green", name: "Verde", class: "bg-green-500" },
  { key: "red", name: "Rosso", class: "bg-red-500" },
  { key: "orange", name: "Arancione", class: "bg-orange-500" },
  { key: "purple", name: "Viola", class: "bg-purple-500" },
  { key: "pink", name: "Rosa", class: "bg-pink-500" },
  { key: "cyan", name: "Ciano", class: "bg-cyan-500" },
  { key: "yellow", name: "Giallo", class: "bg-yellow-500" },
  { key: "gray", name: "Grigio", class: "bg-gray-500" },
]

function NewCategoryForm() {
  const router = useRouter()
  const { addCategory } = useCategoriesContext()
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState(false)
  const [formData, setFormData] = useState<Omit<Category, "id" | "createdAt" | "updatedAt">>({
    key: "",
    name: "",
    description: "",
    icon: "Folder",
    color: "blue",
    subcategories: {},
  })
  const [currentSubcategory, setCurrentSubcategory] = useState({ key: "", name: "" })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1500))

    try {
      addCategory(formData)
      setSuccess(true)
      setLoading(false)

      // Redirect after success
      setTimeout(() => {
        router.push("/admin/categorie")
      }, 2000)
    } catch (error) {
      console.error("Error creating category:", error)
      setLoading(false)
    }
  }

  const addSubcategory = () => {
    if (currentSubcategory.key.trim() && currentSubcategory.name.trim()) {
      setFormData({
        ...formData,
        subcategories: {
          ...formData.subcategories,
          [currentSubcategory.key.trim()]: currentSubcategory.name.trim(),
        },
      })
      setCurrentSubcategory({ key: "", name: "" })
    }
  }

  const removeSubcategory = (keyToRemove: string) => {
    const newSubcategories = { ...formData.subcategories }
    delete newSubcategories[keyToRemove]
    setFormData({
      ...formData,
      subcategories: newSubcategories,
    })
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      e.preventDefault()
      addSubcategory()
    }
  }

  // Auto-generate key from name
  const handleNameChange = (name: string) => {
    setFormData({
      ...formData,
      name,
      key: name
        .toLowerCase()
        .replace(/[^a-z0-9\s]/g, "")
        .replace(/\s+/g, "-")
        .substring(0, 20),
    })
  }

  if (success) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardContent className="text-center p-8">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Save className="w-8 h-8 text-green-600" />
            </div>
            <h2 className="text-2xl font-bold mb-2">Categoria Creata!</h2>
            <p className="text-gray-600 mb-6">La nuova categoria è stata aggiunta con successo.</p>
            <Button asChild>
              <Link href="/admin/categorie">Torna alle Categorie</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="sm" asChild>
                <Link href="/admin/categorie">
                  <ArrowLeft className="w-4 h-4 mr-1" />
                  Torna alle Categorie
                </Link>
              </Button>
              <div>
                <h1 className="text-2xl font-bold">Nuova Categoria</h1>
                <p className="text-gray-600">Crea una nuova categoria per i prodotti</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <form onSubmit={handleSubmit} className="space-y-8">
            {/* Basic Information */}
            <Card>
              <CardHeader>
                <CardTitle>Informazioni Base</CardTitle>
                <CardDescription>Inserisci le informazioni principali della categoria</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="name">Nome Categoria *</Label>
                    <Input
                      id="name"
                      value={formData.name}
                      onChange={(e) => handleNameChange(e.target.value)}
                      placeholder="Es. Carte da Collezione"
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="key">Chiave Categoria *</Label>
                    <Input
                      id="key"
                      value={formData.key}
                      onChange={(e) => setFormData({ ...formData, key: e.target.value })}
                      placeholder="carte-collezione"
                      required
                    />
                    <p className="text-sm text-gray-500">Usata negli URL, solo lettere minuscole e trattini</p>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">Descrizione *</Label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    placeholder="Descrivi la categoria..."
                    rows={3}
                    required
                  />
                </div>
              </CardContent>
            </Card>

            {/* Appearance */}
            <Card>
              <CardHeader>
                <CardTitle>Aspetto</CardTitle>
                <CardDescription>Personalizza l'aspetto della categoria</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="icon">Icona</Label>
                    <Select value={formData.icon} onValueChange={(value) => setFormData({ ...formData, icon: value })}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {availableIcons.map((icon) => (
                          <SelectItem key={icon.key} value={icon.key}>
                            <div className="flex items-center gap-2">
                              <span>{icon.emoji}</span>
                              <span>{icon.name}</span>
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="color">Colore</Label>
                    <Select
                      value={formData.color}
                      onValueChange={(value) => setFormData({ ...formData, color: value })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {availableColors.map((color) => (
                          <SelectItem key={color.key} value={color.key}>
                            <div className="flex items-center gap-2">
                              <div className={`w-4 h-4 rounded-full ${color.class}`} />
                              <span>{color.name}</span>
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Preview */}
                <div className="p-4 border rounded-lg bg-gray-50">
                  <Label className="text-sm font-medium mb-2 block">Anteprima:</Label>
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-12 h-12 rounded-full flex items-center justify-center ${
                        formData.color === "blue"
                          ? "bg-blue-100 text-blue-800"
                          : formData.color === "green"
                            ? "bg-green-100 text-green-800"
                            : formData.color === "red"
                              ? "bg-red-100 text-red-800"
                              : formData.color === "orange"
                                ? "bg-orange-100 text-orange-800"
                                : formData.color === "purple"
                                  ? "bg-purple-100 text-purple-800"
                                  : formData.color === "pink"
                                    ? "bg-pink-100 text-pink-800"
                                    : formData.color === "cyan"
                                      ? "bg-cyan-100 text-cyan-800"
                                      : formData.color === "yellow"
                                        ? "bg-yellow-100 text-yellow-800"
                                        : "bg-gray-100 text-gray-800"
                      }`}
                    >
                      <span className="text-2xl">
                        {availableIcons.find((i) => i.key === formData.icon)?.emoji || "📁"}
                      </span>
                    </div>
                    <div>
                      <h3 className="font-semibold">{formData.name || "Nome Categoria"}</h3>
                      <p className="text-sm text-gray-600">{formData.description || "Descrizione categoria"}</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Subcategories */}
            <Card>
              <CardHeader>
                <CardTitle>Sottocategorie</CardTitle>
                <CardDescription>Aggiungi sottocategorie per organizzare meglio i prodotti</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid md:grid-cols-3 gap-2">
                  <Input
                    placeholder="Chiave (es. pokemon)"
                    value={currentSubcategory.key}
                    onChange={(e) => setCurrentSubcategory({ ...currentSubcategory, key: e.target.value })}
                    onKeyPress={handleKeyPress}
                  />
                  <Input
                    placeholder="Nome (es. Pokémon)"
                    value={currentSubcategory.name}
                    onChange={(e) => setCurrentSubcategory({ ...currentSubcategory, name: e.target.value })}
                    onKeyPress={handleKeyPress}
                  />
                  <Button
                    type="button"
                    onClick={addSubcategory}
                    disabled={!currentSubcategory.key.trim() || !currentSubcategory.name.trim()}
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Aggiungi
                  </Button>
                </div>

                {Object.keys(formData.subcategories).length > 0 && (
                  <div className="space-y-2">
                    <Label>Sottocategorie aggiunte:</Label>
                    <div className="flex flex-wrap gap-2">
                      {Object.entries(formData.subcategories).map(([key, name]) => (
                        <Badge key={key} variant="secondary" className="flex items-center gap-1">
                          {name}
                          <button
                            type="button"
                            onClick={() => removeSubcategory(key)}
                            className="ml-1 hover:text-red-500"
                          >
                            <X className="w-3 h-3" />
                          </button>
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Actions */}
            <div className="flex gap-4 justify-end">
              <Button type="button" variant="outline" asChild>
                <Link href="/admin/categorie">Annulla</Link>
              </Button>
              <Button type="submit" disabled={loading}>
                {loading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Creazione in corso...
                  </>
                ) : (
                  <>
                    <Save className="w-4 h-4 mr-2" />
                    Crea Categoria
                  </>
                )}
              </Button>
            </div>
          </form>
        </div>
      </div>
    </div>
  )
}

export default function NewCategoryPage() {
  return (
    <ProtectedRoute requireAdmin>
      <NewCategoryForm />
    </ProtectedRoute>
  )
}
