"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Package, ShoppingCart, TrendingUp, Plus, Eye, Edit, Calendar, Star, Folder } from "lucide-react"
import Link from "next/link"
import { ProtectedRoute } from "@/components/protected-route"
import { useAuthContext } from "@/components/auth-provider"
import { useCategoriesContext } from "@/components/categories-provider"
import { products } from "@/lib/products"

function AdminDashboard() {
  const { user } = useAuthContext()
  const { categories, categoriesCount } = useCategoriesContext()

  const stats = {
    totalProducts: products.length,
    featuredProducts: products.filter((p) => p.featured).length,
    inStockProducts: products.filter((p) => p.inStock).length,
    outOfStockProducts: products.filter((p) => !p.inStock).length,
    totalCategories: categoriesCount,
  }

  const recentProducts = products.slice(0, 5)
  const recentCategories = categories.slice(0, 3)

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-2xl font-bold">Dashboard Amministratore</h1>
              <p className="text-gray-600">Benvenuto, {user?.name}</p>
            </div>
            <div className="flex gap-4">
              <Button asChild>
                <Link href="/admin/prodotti/nuovo">
                  <Plus className="w-4 h-4 mr-2" />
                  Nuovo Prodotto
                </Link>
              </Button>
              <Button variant="outline" asChild>
                <Link href="/admin/categorie/nuova">
                  <Folder className="w-4 h-4 mr-2" />
                  Nuova Categoria
                </Link>
              </Button>
              <Button variant="outline" asChild>
                <Link href="/">
                  <Eye className="w-4 h-4 mr-2" />
                  Visualizza Sito
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* Stats Cards */}
        <div className="grid md:grid-cols-2 lg:grid-cols-5 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Prodotti Totali</CardTitle>
              <Package className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.totalProducts}</div>
              <p className="text-xs text-muted-foreground">Tutti i prodotti nel catalogo</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Categorie</CardTitle>
              <Folder className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.totalCategories}</div>
              <p className="text-xs text-muted-foreground">Categorie attive</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">In Evidenza</CardTitle>
              <Star className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.featuredProducts}</div>
              <p className="text-xs text-muted-foreground">Prodotti in evidenza</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Disponibili</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">{stats.inStockProducts}</div>
              <p className="text-xs text-muted-foreground">Prodotti in magazzino</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Esauriti</CardTitle>
              <ShoppingCart className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-red-600">{stats.outOfStockProducts}</div>
              <p className="text-xs text-muted-foreground">Prodotti esauriti</p>
            </CardContent>
          </Card>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Quick Actions */}
          <Card>
            <CardHeader>
              <CardTitle>Azioni Rapide</CardTitle>
              <CardDescription>Gestisci il tuo negozio</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Button className="w-full justify-start" asChild>
                <Link href="/admin/prodotti/nuovo">
                  <Plus className="w-4 h-4 mr-2" />
                  Aggiungi Nuovo Prodotto
                </Link>
              </Button>
              <Button className="w-full justify-start" asChild>
                <Link href="/admin/categorie/nuova">
                  <Folder className="w-4 h-4 mr-2" />
                  Crea Nuova Categoria
                </Link>
              </Button>
              <Button variant="outline" className="w-full justify-start bg-transparent" asChild>
                <Link href="/admin/prodotti">
                  <Edit className="w-4 h-4 mr-2" />
                  Gestisci Prodotti
                </Link>
              </Button>
              <Button variant="outline" className="w-full justify-start bg-transparent" asChild>
                <Link href="/admin/categorie">
                  <Edit className="w-4 h-4 mr-2" />
                  Gestisci Categorie
                </Link>
              </Button>
              <Button variant="outline" className="w-full justify-start bg-transparent" asChild>
                <Link href="/prodotti">
                  <Eye className="w-4 h-4 mr-2" />
                  Visualizza Catalogo
                </Link>
              </Button>
            </CardContent>
          </Card>

          {/* Recent Products */}
          <Card>
            <CardHeader>
              <CardTitle>Prodotti Recenti</CardTitle>
              <CardDescription>Gli ultimi prodotti aggiunti</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentProducts.map((product) => (
                  <div key={product.id} className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="font-semibold text-sm">{product.name}</h3>
                        {product.featured && <Badge className="bg-red-500 text-white text-xs">Featured</Badge>}
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-blue-600 text-sm">€{product.price.toFixed(2)}</span>
                        <Badge variant="outline" className="text-xs">
                          {product.category.toUpperCase()}
                        </Badge>
                      </div>
                    </div>
                    <div className="flex gap-1">
                      <Button size="sm" variant="outline" asChild>
                        <Link href={`/prodotto/${product.id}`}>
                          <Eye className="w-3 h-3" />
                        </Link>
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
              <div className="mt-4 text-center">
                <Button variant="outline" size="sm" asChild>
                  <Link href="/admin/prodotti">Visualizza Tutti</Link>
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Recent Categories */}
          <Card>
            <CardHeader>
              <CardTitle>Categorie</CardTitle>
              <CardDescription>Le tue categorie attive</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentCategories.map((category) => (
                  <div key={category.id} className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-center gap-3">
                      <div
                        className={`w-8 h-8 rounded-full flex items-center justify-center text-sm ${
                          category.color === "blue"
                            ? "bg-blue-100 text-blue-800"
                            : category.color === "green"
                              ? "bg-green-100 text-green-800"
                              : category.color === "red"
                                ? "bg-red-100 text-red-800"
                                : category.color === "orange"
                                  ? "bg-orange-100 text-orange-800"
                                  : category.color === "purple"
                                    ? "bg-purple-100 text-purple-800"
                                    : category.color === "pink"
                                      ? "bg-pink-100 text-pink-800"
                                      : category.color === "cyan"
                                        ? "bg-cyan-100 text-cyan-800"
                                        : category.color === "yellow"
                                          ? "bg-yellow-100 text-yellow-800"
                                          : "bg-gray-100 text-gray-800"
                        }`}
                      >
                        {category.icon === "Gamepad2"
                          ? "🎮"
                          : category.icon === "Sparkles"
                            ? "✨"
                            : category.icon === "Gift"
                              ? "🎁"
                              : category.icon === "BookOpen"
                                ? "📚"
                                : category.icon === "Waves"
                                  ? "🌊"
                                  : category.icon === "Gem"
                                    ? "💎"
                                    : "📁"}
                      </div>
                      <div>
                        <h3 className="font-semibold text-sm">{category.name}</h3>
                        <p className="text-xs text-gray-600">
                          {Object.keys(category.subcategories).length} sottocategorie
                        </p>
                      </div>
                    </div>
                    <Button size="sm" variant="outline" asChild>
                      <Link href={`/admin/categorie/modifica/${category.id}`}>
                        <Edit className="w-3 h-3" />
                      </Link>
                    </Button>
                  </div>
                ))}
              </div>
              <div className="mt-4 text-center">
                <Button variant="outline" size="sm" asChild>
                  <Link href="/admin/categorie">Gestisci Tutte</Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* System Info */}
        <Card className="mt-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="w-5 h-5" />
              Informazioni Sistema
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-4 gap-4 text-sm">
              <div>
                <span className="font-medium">Ultimo accesso:</span>
                <p className="text-gray-600">{new Date().toLocaleString("it-IT")}</p>
              </div>
              <div>
                <span className="font-medium">Prodotti totali:</span>
                <p className="text-gray-600">{stats.totalProducts}</p>
              </div>
              <div>
                <span className="font-medium">Categorie attive:</span>
                <p className="text-gray-600">{stats.totalCategories}</p>
              </div>
              <div>
                <span className="font-medium">Stato:</span>
                <p className="text-green-600">Operativo</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

export default function AdminPage() {
  return (
    <ProtectedRoute requireAdmin>
      <AdminDashboard />
    </ProtectedRoute>
  )
}
