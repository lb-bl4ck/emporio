"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Gamepad2, Sparkles, Gift, BookOpen, Waves, Gem, Heart, Zap, Sun, GraduationCap, Newspaper } from "lucide-react"
import Link from "next/link"
import { getFeaturedProducts } from "@/lib/products"
import { ProductCard } from "@/components/product-card"
import { useCategoriesContext } from "@/components/categories-provider"

const iconComponents: Record<string, any> = {
  Gamepad2,
  Sparkles,
  Gift,
  BookOpen,
  Waves,
  Gem,
  Heart,
  Zap,
  Sun,
  GraduationCap,
  Newspaper,
}

const jsonLd = {
  "@context": "https://schema.org",
  "@type": "CollectionPage",
  name: "Prodotti Emporio Bianchi",
  description: "Catalogo completo dei prodotti disponibili da Emporio Bianchi a Cervia",
  url: "https://emporiobianchicervia.com/prodotti",
  mainEntity: {
    "@type": "ItemList",
    name: "Categorie Prodotti",
    itemListElement: [
      {
        "@type": "ListItem",
        position: 1,
        name: "Carte TCG",
        description: "Trading Card Games: Pokémon, Yu-Gi-Oh!, Magic The Gathering",
      },
      {
        "@type": "ListItem",
        position: 2,
        name: "Giocattoli",
        description: "Giochi educativi, puzzle, costruzioni e action figures",
      },
      {
        "@type": "ListItem",
        position: 3,
        name: "Edicola",
        description: "Materiale scolastico, cancelleria, libri e giornali",
      },
      {
        "@type": "ListItem",
        position: 4,
        name: "Giocattoli da Mare",
        description: "Secchielli, palette colorate, formine per la sabbia e molto altro",
      },
      {
        "@type": "ListItem",
        position: 5,
        name: "Gioielli e Bijoux",
        description: "Accessori alla moda e gioielli eleganti",
      },
    ],
  },
}

export default function ProdottiPageClient() {
  const { categories, getCategoriesForProducts } = useCategoriesContext()
  const categoriesForProducts = getCategoriesForProducts()

  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
      <div className="min-h-screen py-8">
        <div className="container mx-auto px-4">
          {/* Header */}
          <div className="text-center mb-12">
            <h1 className="text-5xl font-bold mb-4">I Nostri Prodotti</h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Scopri la nostra vasta selezione di prodotti a Cervia. Qualità, varietà e passione in ogni categoria che
              offriamo.
            </p>
          </div>

          {/* Dynamic Categories Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-8 mb-16">
            {categories.map((category) => {
              const IconComponent = iconComponents[category.icon] || Sparkles
              const colorClasses = {
                blue: "bg-blue-100 text-blue-600",
                green: "bg-green-100 text-green-600",
                red: "bg-red-100 text-red-600",
                orange: "bg-orange-100 text-orange-600",
                purple: "bg-purple-100 text-purple-600",
                pink: "bg-pink-100 text-pink-600",
                cyan: "bg-cyan-100 text-cyan-600",
                yellow: "bg-yellow-100 text-yellow-600",
                gray: "bg-gray-100 text-gray-600",
              }

              return (
                <Card key={category.id} className="hover:shadow-lg transition-shadow h-full flex flex-col">
                  <CardHeader className="text-center flex-shrink-0">
                    <div
                      className={`w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 ${
                        colorClasses[category.color as keyof typeof colorClasses] || colorClasses.gray
                      }`}
                    >
                      <IconComponent className="w-8 h-8" />
                    </div>
                    <CardTitle className="text-xl lg:text-2xl leading-tight min-h-[3rem] flex items-center justify-center text-center">
                      {category.name}
                    </CardTitle>
                    <CardDescription className="text-center leading-relaxed min-h-[2.5rem] flex items-center justify-center">
                      {category.description}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="flex flex-col flex-1">
                    <div className="flex-1 mb-4">
                      <ul className="space-y-2 text-sm text-gray-600">
                        {Object.entries(category.subcategories)
                          .slice(0, 4)
                          .map(([key, name]) => (
                            <li key={key}>• {name}</li>
                          ))}
                        {Object.keys(category.subcategories).length > 4 && <li>• E molto altro...</li>}
                      </ul>
                    </div>
                    <Button
                      className="w-full mt-auto text-sm px-2 py-2 h-auto min-h-[2.5rem] whitespace-normal leading-tight"
                      asChild
                    >
                      <Link href={`/categoria/${category.key}`}>
                        <span className="text-center">Esplora {category.name}</span>
                      </Link>
                    </Button>
                  </CardContent>
                </Card>
              )
            })}
          </div>

          {/* Prodotti in Evidenza */}
          <section className="mt-16">
            <h2 className="text-3xl font-bold text-center mb-8">Prodotti in Evidenza</h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {getFeaturedProducts().map((product) => (
                <ProductCard key={product.id} product={product} showCategory={true} />
              ))}
            </div>
          </section>

          {/* Call to Action */}
          <section className="text-center bg-gradient-to-r from-blue-50 to-purple-50 rounded-2xl p-12 mt-16">
            <h2 className="text-3xl font-bold mb-4">Non Trovi Quello Che Cerchi?</h2>
            <p className="text-xl text-gray-600 mb-8">
              Contattaci! Possiamo ordinare prodotti specifici o aiutarti a trovare quello che stai cercando.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="bg-blue-600 hover:bg-blue-700" asChild>
                <Link href="/contatti">Contattaci per Ordini Speciali</Link>
              </Button>
              <Button size="lg" variant="outline" asChild>
                <Link href="/contatti">Vieni in Negozio</Link>
              </Button>
            </div>
          </section>
        </div>
      </div>
    </>
  )
}
