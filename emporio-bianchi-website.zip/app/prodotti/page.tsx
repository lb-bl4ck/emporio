import type { Metadata } from "next"
import ProdottiPageClient from "./ProdottiPageClient"

export const metadata: Metadata = {
  title: "Prodotti - Carte TCG, Giocattoli e Collezionismo",
  description:
    "Scopri tutti i nostri prodotti: carte TCG Pokémon, Yu-Gi-Oh!, Magic, giocattoli, edicola, gioielli e giochi da mare. Il meglio del collezionismo a Cervia.",
  keywords: [
    "prodotti Emporio Bianchi",
    "carte TCG Cervia",
    "giocattoli Cervia",
    "edicola Cervia",
    "collezionismo Cervia",
    "Pokémon Yu-Gi-Oh Magic",
    "negozio giochi Cervia",
  ],
  openGraph: {
    title: "Tutti i Prodotti - Emporio Bianchi Cervia",
    description: "Catalogo completo dei prodotti disponibili da Emporio Bianchi a Cervia",
    images: ["/og-prodotti.jpg"],
  },
  alternates: {
    canonical: "https://emporiobianchicervia.com/prodotti",
  },
}

export default function ProdottiPage() {
  return <ProdottiPageClient />
}
