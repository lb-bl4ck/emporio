import { notFound } from "next/navigation"
import { ProductCard } from "@/components/product-card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { getProductsByCategory, categories } from "@/lib/products"
import { ArrowLeft, Filter } from "lucide-react"
import Link from "next/link"

interface CategoryPageProps {
  params: {
    slug: string
  }
}

export default function CategoryPage({ params }: CategoryPageProps) {
  const { slug } = params

  if (!categories[slug as keyof typeof categories]) {
    notFound()
  }

  const category = categories[slug as keyof typeof categories]
  const products = getProductsByCategory(slug)

  return (
    <div className="min-h-screen py-8">
      <div className="container mx-auto px-4">
        {/* Breadcrumb */}
        <div className="flex items-center gap-2 mb-6">
          <Button variant="ghost" size="sm" asChild>
            <Link href="/prodotti">
              <ArrowLeft className="w-4 h-4 mr-1" />
              Tutti i Prodotti
            </Link>
          </Button>
          <span className="text-gray-400">/</span>
          <span className="font-medium">{category.name}</span>
        </div>

        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-5xl font-bold mb-4">{category.name}</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">{category.description}</p>
        </div>

        {/* Filtri per Sottocategorie */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Filter className="w-5 h-5" />
              Filtra per Categoria
            </CardTitle>
            <CardDescription>Seleziona una sottocategoria per affinare la ricerca</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              <Badge variant="outline" className="cursor-pointer hover:bg-blue-50">
                Tutti ({products.length})
              </Badge>
              {Object.entries(category.subcategories).map(([key, name]) => {
                const count = products.filter((p) => p.subcategory === key).length
                return (
                  <Badge key={key} variant="outline" className="cursor-pointer hover:bg-blue-50">
                    {name} ({count})
                  </Badge>
                )
              })}
            </div>
          </CardContent>
        </Card>

        {/* Prodotti */}
        {products.length > 0 ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {products.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        ) : (
          <Card className="text-center py-12">
            <CardContent>
              <h3 className="text-2xl font-semibold mb-4">Nessun Prodotto Trovato</h3>
              <p className="text-gray-600 mb-6">Non ci sono prodotti disponibili in questa categoria al momento.</p>
              <Button asChild>
                <Link href="/prodotti">Torna a Tutti i Prodotti</Link>
              </Button>
            </CardContent>
          </Card>
        )}

        {/* Call to Action */}
        <section className="mt-16 text-center bg-gradient-to-r from-blue-50 to-purple-50 rounded-2xl p-12">
          <h2 className="text-3xl font-bold mb-4">Non Trovi Quello Che Cerchi?</h2>
          <p className="text-xl text-gray-600 mb-8">Contattaci! Possiamo ordinare prodotti specifici per te.</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-blue-600 hover:bg-blue-700" asChild>
              <Link href="/contatti">Contattaci per Ordini Speciali</Link>
            </Button>
            <Button size="lg" variant="outline" asChild>
              <Link href="/contatti">Vieni in Negozio</Link>
            </Button>
          </div>
        </section>
      </div>
    </div>
  )
}

export async function generateStaticParams() {
  return Object.keys(categories).map((slug) => ({
    slug,
  }))
}
