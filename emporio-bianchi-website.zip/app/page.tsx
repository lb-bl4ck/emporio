import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Star, MapPin, Phone, Gamepad2, Sparkles, Gift, BookOpen, Waves, Gem } from "lucide-react"
import Link from "next/link"
import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Emporio Bianchi Cervia - Carte TCG, Giocattoli e Collezionismo",
  description:
    "Il negozio storico di Cervia per carte TCG Pokémon, Yu-Gi-Oh!, Magic, giocattoli, edicola e collezionismo. Viale Sicilia 61 - Esperienza e passione dal 1950.",
  keywords: [
    "carte TCG Cervia",
    "Pokémon Cervia",
    "Yu-Gi-Oh Cervia",
    "Magic Cervia",
    "giocattoli Cervia",
    "edicola Cervia",
    "negozio giochi Cervia",
    "collezionismo Cervia",
    "Viale Sicilia 61",
  ],
  openGraph: {
    title: "Emporio Bianchi Cervia - Il Tuo Negozio di Fiducia",
    description:
      "Carte TCG, giocattoli, edicola e collezionismo nel cuore di Cervia. Vieni a scoprire la nostra passione!",
    images: ["/og-home.jpg"],
  },
  alternates: {
    canonical: "https://emporiobianchicervia.com",
  },
}

const jsonLd = {
  "@context": "https://schema.org",
  "@type": "Store",
  name: "Emporio Bianchi",
  description: "Negozio specializzato in carte TCG, giocattoli e collezionismo a Cervia",
  image: "https://emporiobianchicervia.com/og-home.jpg",
  address: {
    "@type": "PostalAddress",
    streetAddress: "Viale Sicilia 61",
    addressLocality: "Cervia",
    postalCode: "48015",
    addressCountry: "IT",
  },
  hasOfferCatalog: {
    "@type": "OfferCatalog",
    name: "Prodotti Emporio Bianchi",
    itemListElement: [
      {
        "@type": "Offer",
        itemOffered: {
          "@type": "Product",
          name: "Carte TCG Pokémon",
          category: "Trading Card Games",
        },
      },
      {
        "@type": "Offer",
        itemOffered: {
          "@type": "Product",
          name: "Giocattoli Educativi",
          category: "Toys",
        },
      },
    ],
  },
}

export default function HomePage() {
  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
      <div className="min-h-screen">
        {/* Hero Section */}
        <section className="relative bg-gradient-to-br from-blue-600 via-purple-600 to-green-600 text-white py-20">
          <div className="absolute inset-0 bg-black/20"></div>
          <div className="container mx-auto px-4 relative z-10">
            <div className="max-w-4xl mx-auto text-center">
              <h1 className="text-5xl md:text-7xl font-bold mb-6">Emporio Bianchi Cervia</h1>
              <p className="text-xl md:text-2xl mb-8 opacity-90">
                Il tuo punto di riferimento storico a Cervia per giochi, carte TCG e collezionismo dal 1950
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button size="lg" className="bg-white text-blue-600 hover:bg-gray-100" asChild>
                  <Link href="/prodotti">Scopri i Prodotti</Link>
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  className="border-white text-white hover:bg-white hover:text-blue-600 bg-transparent"
                  asChild
                >
                  <Link href="/contatti">Contattaci</Link>
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Prodotti in Evidenza */}
        <section className="py-16 bg-gray-50">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-4xl font-bold mb-4">I Nostri Prodotti</h2>
              <p className="text-xl text-gray-600 max-w-2xl mx-auto">
                Dalle carte TCG più ricercate ai giocattoli educativi, abbiamo tutto quello che cerchi a Cervia
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-8">
              <Card className="hover:shadow-lg transition-shadow h-full flex flex-col">
                <CardHeader className="text-center flex-shrink-0">
                  <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Gamepad2 className="w-8 h-8 text-blue-600" />
                  </div>
                  <CardTitle className="text-2xl">Carte TCG</CardTitle>
                  <CardDescription>Pokémon, Yu-Gi-Oh!, Magic e molto altro</CardDescription>
                </CardHeader>
                <CardContent className="flex flex-col flex-1">
                  <div className="flex-1 mb-4">
                    <ul className="space-y-2 text-sm text-gray-600">
                      <li>• Booster pack e box sigillati</li>
                      <li>• Carte singole rare</li>
                      <li>• Accessori per il gioco</li>
                      <li>• Tornei e eventi</li>
                    </ul>
                  </div>
                  <Button className="w-full mt-auto" asChild>
                    <Link href="/prodotti#tcg">Esplora TCG</Link>
                  </Button>
                </CardContent>
              </Card>

              <Card className="hover:shadow-lg transition-shadow h-full flex flex-col">
                <CardHeader className="text-center flex-shrink-0">
                  <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Sparkles className="w-8 h-8 text-green-600" />
                  </div>
                  <CardTitle className="text-2xl">Giocattoli</CardTitle>
                  <CardDescription>Per bambini piccoli e grandi</CardDescription>
                </CardHeader>
                <CardContent className="flex flex-col flex-1">
                  <div className="flex-1 mb-4">
                    <ul className="space-y-2 text-sm text-gray-600">
                      <li>• Giochi educativi</li>
                      <li>• Action figures</li>
                      <li>• Puzzle e costruzioni</li>
                      <li>• Giochi da tavolo</li>
                    </ul>
                  </div>
                  <Button className="w-full mt-auto" asChild>
                    <Link href="/prodotti#giocattoli">Scopri Giocattoli</Link>
                  </Button>
                </CardContent>
              </Card>

              <Card className="hover:shadow-lg transition-shadow h-full flex flex-col">
                <CardHeader className="text-center flex-shrink-0">
                  <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Gift className="w-8 h-8 text-orange-600" />
                  </div>
                  <CardTitle className="text-2xl">Idee Regalo</CardTitle>
                  <CardDescription>Regali originali per ogni occasione</CardDescription>
                </CardHeader>
                <CardContent className="flex flex-col flex-1">
                  <div className="flex-1 mb-4">
                    <ul className="space-y-2 text-sm text-gray-600">
                      <li>• Collezioni esclusive</li>
                      <li>• Gadget unici</li>
                      <li>• Confezioni regalo</li>
                      <li>• Consulenza personalizzata</li>
                    </ul>
                  </div>
                  <Button className="w-full mt-auto" asChild>
                    <Link href="/prodotti#regali">Trova Regali</Link>
                  </Button>
                </CardContent>
              </Card>

              <Card className="hover:shadow-lg transition-shadow h-full flex flex-col">
                <CardHeader className="text-center flex-shrink-0">
                  <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <BookOpen className="w-8 h-8 text-red-600" />
                  </div>
                  <CardTitle className="text-2xl">Edicola</CardTitle>
                  <CardDescription>Tutto per la scuola e l'ufficio</CardDescription>
                </CardHeader>
                <CardContent className="flex flex-col flex-1">
                  <div className="flex-1 mb-4">
                    <ul className="space-y-2 text-sm text-gray-600">
                      <li>• Zaini e cartelle</li>
                      <li>• Libri e quaderni</li>
                      <li>• Cancelleria e materiale scolastico</li>
                      <li>• Riviste e giornali</li>
                    </ul>
                  </div>
                  <Button className="w-full mt-auto" asChild>
                    <Link href="/prodotti#edicola">Scopri Edicola</Link>
                  </Button>
                </CardContent>
              </Card>

              <Card className="hover:shadow-lg transition-shadow h-full flex flex-col">
                <CardHeader className="text-center flex-shrink-0">
                  <div className="w-16 h-16 bg-cyan-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Waves className="w-8 h-8 text-cyan-600" />
                  </div>
                  <CardTitle className="text-2xl">Mare</CardTitle>
                  <CardDescription>Giocattoli per la spiaggia</CardDescription>
                </CardHeader>
                <CardContent className="flex flex-col flex-1">
                  <div className="flex-1 mb-4">
                    <ul className="space-y-2 text-sm text-gray-600">
                      <li>• Secchielli e palette</li>
                      <li>• Materassini e salvagenti</li>
                      <li>• Giochi da spiaggia</li>
                      <li>• Maschere e boccagli</li>
                    </ul>
                  </div>
                  <Button className="w-full mt-auto" asChild>
                    <Link href="/prodotti#mare">Scopri Mare</Link>
                  </Button>
                </CardContent>
              </Card>

              <Card className="hover:shadow-lg transition-shadow h-full flex flex-col">
                <CardHeader className="text-center flex-shrink-0">
                  <div className="w-16 h-16 bg-pink-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Gem className="w-8 h-8 text-pink-600" />
                  </div>
                  <CardTitle className="text-2xl">Gioielli</CardTitle>
                  <CardDescription>Bijoux e accessori</CardDescription>
                </CardHeader>
                <CardContent className="flex flex-col flex-1">
                  <div className="flex-1 mb-4">
                    <ul className="space-y-2 text-sm text-gray-600">
                      <li>• Collane e braccialetti</li>
                      <li>• Orecchini e anelli</li>
                      <li>• Accessori moda</li>
                      <li>• Idee regalo eleganti</li>
                    </ul>
                  </div>
                  <Button className="w-full mt-auto" asChild>
                    <Link href="/prodotti#gioielli">Scopri Gioielli</Link>
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Perché Sceglierci */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-4xl font-bold mb-4">Perché Emporio Bianchi Cervia?</h2>
              <p className="text-xl text-gray-600">Tradizione, passione e competenza al tuo servizio dal 1950</p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              <div className="text-center">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Star className="w-8 h-8 text-blue-600" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Tradizione</h3>
                <p className="text-gray-600">Punto di riferimento storico a Cervia dal 1950</p>
              </div>

              <div className="text-center">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Sparkles className="w-8 h-8 text-green-600" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Competenza</h3>
                <p className="text-gray-600">Staff esperto e appassionato</p>
              </div>

              <div className="text-center">
                <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Gift className="w-8 h-8 text-purple-600" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Varietà</h3>
                <p className="text-gray-600">Ampia selezione per tutte le età</p>
              </div>

              <div className="text-center">
                <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <MapPin className="w-8 h-8 text-orange-600" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Posizione</h3>
                <p className="text-gray-600">Facilmente raggiungibile in centro Cervia</p>
              </div>
            </div>
          </div>
        </section>

        {/* Call to Action */}
        <section className="py-16 bg-gradient-to-r from-blue-600 to-purple-600 text-white">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-4xl font-bold mb-4">Vieni a Trovarci a Cervia!</h2>
            <p className="text-xl mb-8 opacity-90">
              Ti aspettiamo in Viale Sicilia 61 a Cervia per un'esperienza unica
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="bg-white text-blue-600 hover:bg-gray-100" asChild>
                <Link href="/contatti">
                  <MapPin className="w-5 h-5 mr-2" />
                  Come Raggiungerci
                </Link>
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="border-white text-white hover:bg-white hover:text-blue-600 bg-transparent"
                asChild
              >
                <Link href="/contatti">
                  <Phone className="w-5 h-5 mr-2" />
                  Contattaci
                </Link>
              </Button>
            </div>
          </div>
        </section>
      </div>
    </>
  )
}
