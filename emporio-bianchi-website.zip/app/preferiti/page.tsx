"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Heart, Trash2, ShoppingBag, Phone, MapPin } from "lucide-react"
import Image from "next/image"
import Link from "next/link"
import { useFavoritesContext } from "@/components/favorites-provider"

export default function Preferiti() {
  const { favorites, removeFromFavorites, clearFavorites } = useFavoritesContext()

  if (favorites.length === 0) {
    return (
      <div className="min-h-screen py-8">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h1 className="text-5xl font-bold mb-4">I Tuoi Preferiti</h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Salva i prodotti che ti interessano per trovarli facilmente quando vieni in negozio!
            </p>
          </div>

          <Card className="max-w-2xl mx-auto text-center py-12">
            <CardContent>
              <Heart className="w-16 h-16 text-gray-300 mx-auto mb-6" />
              <h3 className="text-2xl font-semibold mb-4">Nessun Prodotto Salvato</h3>
              <p className="text-gray-600 mb-8">
                Inizia a esplorare i nostri prodotti e aggiungi quelli che ti interessano ai preferiti!
              </p>
              <Button size="lg" asChild>
                <Link href="/prodotti">
                  <ShoppingBag className="w-5 h-5 mr-2" />
                  Esplora Prodotti
                </Link>
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen py-8">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-12">
          <div>
            <h1 className="text-5xl font-bold mb-4">I Tuoi Preferiti</h1>
            <p className="text-xl text-gray-600">
              {favorites.length} {favorites.length === 1 ? "prodotto salvato" : "prodotti salvati"}
            </p>
          </div>
          <div className="flex gap-4 mt-4 sm:mt-0">
            <Button variant="outline" onClick={clearFavorites}>
              <Trash2 className="w-4 h-4 mr-2" />
              Svuota Lista
            </Button>
          </div>
        </div>

        {/* Favorites Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 mb-12">
          {favorites.map(({ product, addedAt }) => (
            <Card key={product.id} className="hover:shadow-lg transition-shadow group h-full flex flex-col">
              <CardHeader className="p-4 flex-shrink-0">
                <div className="relative overflow-hidden rounded-lg">
                  <Image
                    src={product.image || "/placeholder.svg"}
                    alt={product.name}
                    width={250}
                    height={300}
                    className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  {product.featured && (
                    <Badge className="absolute top-2 left-2 bg-red-500 text-white">In Evidenza</Badge>
                  )}
                  {!product.inStock && (
                    <Badge className="absolute top-2 right-2 bg-gray-500 text-white">Esaurito</Badge>
                  )}
                  <Button
                    size="sm"
                    variant="destructive"
                    className="absolute top-2 right-2 w-8 h-8 p-0"
                    onClick={() => removeFromFavorites(product.id)}
                  >
                    <Trash2 className="w-4 h-4" />
                    <span className="sr-only">Rimuovi dai preferiti</span>
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="p-4 flex flex-col flex-1">
                <div className="flex-1 space-y-2 mb-4">
                  <CardTitle className="text-lg line-clamp-2">{product.name}</CardTitle>
                  <CardDescription className="text-sm line-clamp-2">{product.description}</CardDescription>
                  <p className="text-xs text-gray-500">Aggiunto il {addedAt.toLocaleDateString("it-IT")}</p>
                </div>
                <div className="flex-shrink-0 space-y-3">
                  <div className="text-center">
                    <span className="text-2xl font-bold text-blue-600">€{product.price.toFixed(2)}</span>
                  </div>
                  <Button size="sm" variant="outline" className="w-full bg-transparent" asChild>
                    <Link href={`/prodotto/${product.id}`}>Vedi Dettagli</Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Call to Action */}
        <section className="text-center bg-gradient-to-r from-blue-50 to-purple-50 rounded-2xl p-12">
          <h2 className="text-3xl font-bold mb-4">Pronto per Acquistare?</h2>
          <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
            Porta questa lista con te quando vieni in negozio! Il nostro staff sarà felice di aiutarti a trovare tutti i
            prodotti che hai salvato.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-blue-600 hover:bg-blue-700" asChild>
              <Link href="/contatti">
                <MapPin className="w-5 h-5 mr-2" />
                Vieni in Negozio
              </Link>
            </Button>
            <Button size="lg" variant="outline" asChild>
              <Link href="tel:+393889307922">
                <Phone className="w-5 h-5 mr-2" />
                Chiamaci Prima
              </Link>
            </Button>
          </div>
        </section>
      </div>
    </div>
  )
}
