"use client"

import { notFound } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { getProductById, getProductsByCategory, categories } from "@/lib/products"
import { ProductCard } from "@/components/product-card"
import { ArrowLeft, Heart, Star, MapPin, Phone } from "lucide-react"
import Image from "next/image"
import Link from "next/link"
import { useFavoritesContext } from "@/components/favorites-provider"

interface ProductPageProps {
  params: {
    id: string
  }
}

export default function ProductPage({ params }: ProductPageProps) {
  const { id } = params
  const product = getProductById(id)
  const { addToFavorites, removeFromFavorites, isFavorite } = useFavoritesContext()

  if (!product) {
    notFound()
  }

  const category = categories[product.category as keyof typeof categories]
  const relatedProducts = getProductsByCategory(product.category)
    .filter((p) => p.id !== product.id)
    .slice(0, 4)

  const handleFavoriteToggle = () => {
    if (isFavorite(product.id)) {
      removeFromFavorites(product.id)
    } else {
      addToFavorites(product)
    }
  }

  return (
    <div className="min-h-screen py-8">
      <div className="container mx-auto px-4">
        {/* Breadcrumb */}
        <div className="flex items-center gap-2 mb-6">
          <Button variant="ghost" size="sm" asChild>
            <Link href="/prodotti">
              <ArrowLeft className="w-4 h-4 mr-1" />
              Tutti i Prodotti
            </Link>
          </Button>
          <span className="text-gray-400">/</span>
          <Link href={`/categoria/${product.category}`} className="text-blue-600 hover:underline">
            {category.name}
          </Link>
          <span className="text-gray-400">/</span>
          <span className="font-medium">{product.name}</span>
        </div>

        {/* Prodotto Principale */}
        <div className="grid lg:grid-cols-2 gap-12 mb-16">
          {/* Immagine */}
          <div className="space-y-4">
            <div className="relative">
              <Image
                src={product.image || "/placeholder.svg"}
                alt={product.name}
                width={500}
                height={600}
                className="w-full h-96 object-cover rounded-lg shadow-lg"
              />
              {product.featured && <Badge className="absolute top-4 left-4 bg-red-500 text-white">In Evidenza</Badge>}
              {!product.inStock && <Badge className="absolute top-4 right-4 bg-gray-500 text-white">Esaurito</Badge>}
            </div>
          </div>

          {/* Dettagli */}
          <div className="space-y-6">
            <div>
              <Badge variant="outline" className="mb-2">
                {category.name}
              </Badge>
              <h1 className="text-4xl font-bold mb-4">{product.name}</h1>
              <div className="flex items-center gap-2 mb-4">
                <div className="flex items-center">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                  ))}
                </div>
                <span className="text-sm text-gray-600">(4.8/5 - 24 recensioni)</span>
              </div>
              <p className="text-lg text-gray-700 leading-relaxed">{product.description}</p>
            </div>

            {/* Tags */}
            {product.tags && (
              <div className="space-y-2">
                <h3 className="font-semibold">Tags:</h3>
                <div className="flex flex-wrap gap-2">
                  {product.tags.map((tag) => (
                    <Badge key={tag} variant="secondary">
                      {tag}
                    </Badge>
                  ))}
                </div>
              </div>
            )}

            {/* Prezzo e Azioni */}
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <span className="text-3xl font-bold text-blue-600">€{product.price.toFixed(2)}</span>
                    <p className="text-sm text-gray-600 mt-1">
                      {product.inStock ? "Disponibile in negozio" : "Attualmente non disponibile"}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-gray-600">Vieni a trovarci</p>
                    <p className="text-sm text-gray-600">in Viale Sicilia 61</p>
                  </div>
                </div>

                <div className="space-y-3">
                  <Button size="lg" className="w-full bg-blue-600 hover:bg-blue-700" asChild>
                    <Link href="/contatti">
                      <MapPin className="w-5 h-5 mr-2" />
                      Vieni in Negozio
                    </Link>
                  </Button>

                  <div className="flex gap-2">
                    <Button variant="outline" size="lg" className="flex-1 bg-transparent" asChild>
                      <Link href="tel:+393889307922">
                        <Phone className="w-5 h-5 mr-2" />
                        Chiamaci
                      </Link>
                    </Button>
                    <Button
                      variant="outline"
                      size="lg"
                      className={`flex-1 ${
                        isFavorite(product.id)
                          ? "bg-red-50 text-red-600 border-red-200 hover:bg-red-100"
                          : "bg-transparent"
                      }`}
                      onClick={handleFavoriteToggle}
                    >
                      <Heart className={`w-5 h-5 mr-2 ${isFavorite(product.id) ? "fill-red-500 text-red-500" : ""}`} />
                      {isFavorite(product.id) ? "Rimuovi dai Preferiti" : "Aggiungi ai Preferiti"}
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Informazioni Aggiuntive */}
            <Card>
              <CardHeader>
                <CardTitle>Informazioni Prodotto</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between">
                  <span className="font-medium">Categoria:</span>
                  <span>{category.name}</span>
                </div>
                {product.subcategory && (
                  <div className="flex justify-between">
                    <span className="font-medium">Sottocategoria:</span>
                    <span>{category.subcategories[product.subcategory]}</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span className="font-medium">Codice Prodotto:</span>
                  <span className="font-mono text-sm">{product.id.toUpperCase()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="font-medium">Disponibilità:</span>
                  <Badge variant={product.inStock ? "default" : "secondary"}>
                    {product.inStock ? "Disponibile" : "Esaurito"}
                  </Badge>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Prodotti Correlati */}
        {relatedProducts.length > 0 && (
          <section>
            <h2 className="text-3xl font-bold mb-8">Prodotti Correlati</h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {relatedProducts.map((relatedProduct) => (
                <ProductCard key={relatedProduct.id} product={relatedProduct} />
              ))}
            </div>
          </section>
        )}
      </div>
    </div>
  )
}
