"use client"

import type React from "react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { MapPin, Phone, Mail, Clock, Car, Bus, Navigation } from "lucide-react"
import Link from "next/link"
import { useState } from "react"

export default function ContattiPage() {
  const [formData, setFormData] = useState({
    nome: "",
    cognome: "",
    email: "",
    telefono: "",
    oggetto: "",
    messaggio: "",
  })

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    console.log("Form submitted:", formData)
    // Here you would typically send the data to your backend
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  return (
    <div className="min-h-screen py-8">
      <div className="container mx-auto px-4">
        {/* Header */}
        <header className="text-center mb-12">
          <h1 className="text-5xl font-bold mb-4">Contattaci</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Siamo qui per aiutarti! Vieni a trovarci in negozio, chiamaci o scrivici. Il nostro staff è sempre pronto a
            rispondere alle tue domande.
          </p>
        </header>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Informazioni di Contatto */}
          <section aria-labelledby="contact-info-heading">
            <div className="space-y-8">
              <div>
                <h2 id="contact-info-heading" className="text-3xl font-bold mb-6">
                  Informazioni di Contatto
                </h2>

                <div className="space-y-6">
                  {/* Indirizzo */}
                  <Card className="hover:shadow-lg transition-shadow">
                    <CardHeader>
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                          <MapPin className="w-6 h-6 text-blue-600" aria-hidden="true" />
                        </div>
                        <div>
                          <CardTitle className="text-xl">Indirizzo</CardTitle>
                          <CardDescription>Vieni a trovarci in negozio</CardDescription>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <address className="not-italic">
                        <p className="text-lg font-semibold">Viale Sicilia 61</p>
                        <p className="text-gray-600">48015 Cervia (RA), Italia</p>
                      </address>
                    </CardContent>
                  </Card>

                  {/* Telefono */}
                  <Card className="hover:shadow-lg transition-shadow">
                    <CardHeader>
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                          <Phone className="w-6 h-6 text-green-600" aria-hidden="true" />
                        </div>
                        <div>
                          <CardTitle className="text-xl">Telefono</CardTitle>
                          <CardDescription>Chiamaci per informazioni</CardDescription>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <Button variant="link" className="p-0 h-auto text-lg font-semibold" asChild>
                        <Link href="tel:+393889307922" aria-label="Chiama il numero +39 388 9307922">
                          +39 388 9307922
                        </Link>
                      </Button>
                      <p className="text-gray-600">
                        <time>Lun-Dom: 7:00-22:00</time>
                      </p>
                    </CardContent>
                  </Card>

                  {/* Email */}
                  <Card className="hover:shadow-lg transition-shadow">
                    <CardHeader>
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                          <Mail className="w-6 h-6 text-purple-600" aria-hidden="true" />
                        </div>
                        <div>
                          <CardTitle className="text-xl">Email</CardTitle>
                          <CardDescription>Scrivici per qualsiasi domanda</CardDescription>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <Button variant="link" className="p-0 h-auto text-lg font-semibold" asChild>
                        <Link
                          href="mailto:info@emporiobianchisas.com"
                          aria-label="Invia email a info@emporiobianchisas.com"
                        >
                          info@emporiobianchisas.com
                        </Link>
                      </Button>
                      <p className="text-gray-600">Risposta entro 24 ore</p>
                    </CardContent>
                  </Card>

                  {/* Orari */}
                  <Card className="hover:shadow-lg transition-shadow">
                    <CardHeader>
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center">
                          <Clock className="w-6 h-6 text-orange-600" aria-hidden="true" />
                        </div>
                        <div>
                          <CardTitle className="text-xl">Orari di Apertura</CardTitle>
                          <CardDescription>Quando puoi trovarci</CardDescription>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <dl className="space-y-2">
                        <div className="flex justify-between">
                          <dt className="font-medium">Lunedì - Sabato:</dt>
                          <dd>
                            <time>7:00 - 22:00</time>
                          </dd>
                        </div>
                        <div className="flex justify-between">
                          <dt className="font-medium">Domenica:</dt>
                          <dd>
                            <time>7:00 - 22:00</time>
                          </dd>
                        </div>
                      </dl>
                    </CardContent>
                  </Card>
                </div>
              </div>

              {/* Come Raggiungerci */}
              <div>
                <h3 className="text-2xl font-bold mb-4">Come Raggiungerci</h3>
                <div className="grid md:grid-cols-2 gap-4">
                  <Card>
                    <CardHeader>
                      <div className="flex items-center gap-2">
                        <Car className="w-5 h-5 text-blue-600" aria-hidden="true" />
                        <CardTitle className="text-lg">In Auto</CardTitle>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm text-gray-600">
                        Parcheggio disponibile nelle vicinanze. Facilmente raggiungibile dal centro di Cervia.
                      </p>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <div className="flex items-center gap-2">
                        <Bus className="w-5 h-5 text-green-600" aria-hidden="true" />
                        <CardTitle className="text-lg">Mezzi Pubblici</CardTitle>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm text-gray-600">
                        Fermata autobus a 100 metri. Linee urbane e extraurbane disponibili.
                      </p>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </div>
          </section>

          {/* Form di Contatto */}
          <section aria-labelledby="contact-form-heading">
            <Card className="h-fit">
              <CardHeader>
                <CardTitle id="contact-form-heading" className="text-2xl">
                  Inviaci un Messaggio
                </CardTitle>
                <CardDescription>Compila il form e ti risponderemo il prima possibile</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6" noValidate>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="nome">Nome *</Label>
                      <Input
                        id="nome"
                        name="nome"
                        type="text"
                        placeholder="Il tuo nome"
                        value={formData.nome}
                        onChange={handleInputChange}
                        required
                        aria-required="true"
                        aria-describedby="nome-error"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="cognome">Cognome *</Label>
                      <Input
                        id="cognome"
                        name="cognome"
                        type="text"
                        placeholder="Il tuo cognome"
                        value={formData.cognome}
                        onChange={handleInputChange}
                        required
                        aria-required="true"
                        aria-describedby="cognome-error"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="email">Email *</Label>
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      placeholder="la-tua-email@esempio.com"
                      value={formData.email}
                      onChange={handleInputChange}
                      required
                      aria-required="true"
                      aria-describedby="email-error"
                      autoComplete="email"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="telefono">Telefono</Label>
                    <Input
                      id="telefono"
                      name="telefono"
                      type="tel"
                      placeholder="+39 123 456 7890"
                      value={formData.telefono}
                      onChange={handleInputChange}
                      autoComplete="tel"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="oggetto">Oggetto *</Label>
                    <Input
                      id="oggetto"
                      name="oggetto"
                      type="text"
                      placeholder="Di cosa vuoi parlarci?"
                      value={formData.oggetto}
                      onChange={handleInputChange}
                      required
                      aria-required="true"
                      aria-describedby="oggetto-error"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="messaggio">Messaggio *</Label>
                    <Textarea
                      id="messaggio"
                      name="messaggio"
                      placeholder="Scrivi qui il tuo messaggio..."
                      rows={5}
                      value={formData.messaggio}
                      onChange={handleInputChange}
                      required
                      aria-required="true"
                      aria-describedby="messaggio-error"
                    />
                  </div>

                  <Button type="submit" className="w-full" size="lg">
                    Invia Messaggio
                  </Button>

                  <p className="text-sm text-gray-500 text-center">
                    * Campi obbligatori. Rispettiamo la tua privacy e non condivideremo mai i tuoi dati con terze parti.
                  </p>
                </form>
              </CardContent>
            </Card>
          </section>
        </div>

        {/* Mappa */}
        <section className="mt-16" aria-labelledby="location-heading">
          <h2 id="location-heading" className="text-3xl font-bold text-center mb-8">
            Dove Siamo
          </h2>
          <Card className="overflow-hidden">
            <CardContent className="p-0">
              <div
                className="bg-gray-200 h-96 flex items-center justify-center"
                role="img"
                aria-label="Mappa del negozio"
              >
                <div className="text-center">
                  <MapPin className="w-16 h-16 text-gray-400 mx-auto mb-4" aria-hidden="true" />
                  <p className="text-xl font-semibold text-gray-600">Viale Sicilia 61, Cervia (RA)</p>
                  <p className="text-gray-500 mb-4">Il nostro negozio ti aspetta nel cuore di Cervia</p>
                  <Button variant="outline" asChild>
                    <Link
                      href="https://maps.google.com/?q=Viale+Sicilia+61,+Cervia"
                      target="_blank"
                      rel="noopener noreferrer"
                      aria-label="Apri la posizione del negozio in Google Maps (si apre in una nuova finestra)"
                    >
                      <Navigation className="w-4 h-4 mr-2" aria-hidden="true" />
                      Apri in Google Maps
                    </Link>
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </section>

        {/* Call to Action */}
        <section className="mt-16 text-center bg-gradient-to-r from-blue-50 to-purple-50 rounded-2xl p-12">
          <h2 className="text-3xl font-bold mb-4">Ti Aspettiamo!</h2>
          <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
            Che tu sia un collezionista esperto o un genitore alla ricerca del regalo perfetto, da Emporio Bianchi
            troverai sempre un'accoglienza calorosa e professionale.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-blue-600 hover:bg-blue-700" asChild>
              <Link href="tel:+393889307922" aria-label="Chiama il negozio al numero +39 388 9307922">
                <Phone className="w-5 h-5 mr-2" aria-hidden="true" />
                Chiamaci Ora
              </Link>
            </Button>
            <Button size="lg" variant="outline" asChild>
              <Link
                href="https://maps.google.com/?q=Viale+Sicilia+61,+Cervia"
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Visualizza la posizione del negozio su Google Maps (si apre in una nuova finestra)"
              >
                <MapPin className="w-5 h-5 mr-2" aria-hidden="true" />
                Vieni in Negozio
              </Link>
            </Button>
          </div>
        </section>
      </div>
    </div>
  )
}
