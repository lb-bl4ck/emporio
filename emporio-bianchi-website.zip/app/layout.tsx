import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { FavoritesProvider } from "@/components/favorites-provider"
import { AuthProvider } from "@/components/auth-provider"
import { CategoriesProvider } from "@/components/categories-provider"
import { ScrollToTop } from "@/components/scroll-to-top"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: {
    default: "Emporio Bianchi - Giochi, Carte TCG e Collezionismo a Cervia",
    template: "%s | Emporio Bianchi Cervia",
  },
  description:
    "Il punto di riferimento storico a Cervia per carte TCG (Pokémon, Yu-Gi-Oh!, Magic), giocattoli, edicola e collezionismo. Viale Sicilia 61 - Passione, competenza e tradizione dal 1950.",
  keywords: [
    "carte TCG Cervia",
    "Pokémon Cervia",
    "Yu-Gi-Oh Cervia",
    "Magic The Gathering Cervia",
    "giocattoli Cervia",
    "edicola Cervia",
    "collezionismo Cervia",
    "Emporio Bianchi",
    "negozio giochi Cervia",
    "Viale Sicilia 61",
    "Romagna",
    "Ravenna",
  ],
  authors: [{ name: "Emporio Bianchi di Chaves Diego Humberto SAS" }],
  creator: "Emporio Bianchi",
  publisher: "Emporio Bianchi",
  formatDetection: {
    email: false,
    address: false,
    telephone: false,
  },
  metadataBase: new URL("https://emporiobianchicervia.com"),
  alternates: {
    canonical: "/",
  },
  openGraph: {
    title: "Emporio Bianchi - Giochi, Carte TCG e Collezionismo a Cervia",
    description:
      "Il punto di riferimento storico a Cervia per carte TCG, giocattoli e collezionismo. Viale Sicilia 61 - Passione e competenza dal 1950.",
    url: "https://emporiobianchicervia.com",
    siteName: "Emporio Bianchi Cervia",
    images: [
      {
        url: "/og-image.jpg",
        width: 1200,
        height: 630,
        alt: "Emporio Bianchi - Negozio di giochi e carte TCG a Cervia",
      },
    ],
    locale: "it_IT",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Emporio Bianchi - Giochi e Carte TCG a Cervia",
    description: "Il punto di riferimento per carte TCG, giocattoli e collezionismo a Cervia. Viale Sicilia 61.",
    images: ["/og-image.jpg"],
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-video-preview": -1,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
  verification: {
    google: "your-google-verification-code",
  },
    generator: 'v0.dev'
}

const jsonLd = {
  "@context": "https://schema.org",
  "@type": "LocalBusiness",
  name: "Emporio Bianchi",
  image: "https://emporiobianchicervia.com/og-image.jpg",
  "@id": "https://emporiobianchicervia.com",
  url: "https://emporiobianchicervia.com",
  telephone: "+393889307922",
  address: {
    "@type": "PostalAddress",
    streetAddress: "Viale Sicilia 61",
    addressLocality: "Cervia",
    postalCode: "48015",
    addressRegion: "Emilia-Romagna",
    addressCountry: "IT",
  },
  geo: {
    "@type": "GeoCoordinates",
    latitude: 44.2619,
    longitude: 12.3486,
  },
  openingHoursSpecification: [
    {
      "@type": "OpeningHoursSpecification",
      dayOfWeek: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
      opens: "07:00",
      closes: "22:00",
    },
    {
      "@type": "OpeningHoursSpecification",
      dayOfWeek: "Sunday",
      opens: "07:00",
      closes: "22:00",
    },
  ],
  sameAs: ["https://www.facebook.com/emporiobianchicervia", "https://www.instagram.com/emporiobianchicervia"],
  priceRange: "€€",
  servesCuisine: [],
  aggregateRating: {
    "@type": "AggregateRating",
    ratingValue: "4.8",
    reviewCount: "127",
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="it">
      <head>
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
        <link rel="canonical" href="https://emporiobianchicervia.com" />
        <meta name="geo.region" content="IT-ER" />
        <meta name="geo.placename" content="Cervia" />
        <meta name="geo.position" content="44.2619;12.3486" />
        <meta name="ICBM" content="44.2619, 12.3486" />
      </head>
      <body className={inter.className}>
        <AuthProvider>
          <CategoriesProvider>
            <FavoritesProvider>
              <Header />
              <ScrollToTop />
              <main>{children}</main>
              <Footer />
            </FavoritesProvider>
          </CategoriesProvider>
        </AuthProvider>
      </body>
    </html>
  )
}
