import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Clock, Users, Award, Heart, MapPin, Sparkles } from "lucide-react"
import Image from "next/image"

export default function StoriaPage() {
  return (
    <div className="min-h-screen py-8">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-5xl font-bold mb-4">La Nostra Storia</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Una tradizione che continua: dalla fondazione storica alla nuova gestione, sempre al servizio della passione
            per il gioco e il collezionismo.
          </p>
        </div>

        {/* Hero Image */}
        <div className="mb-16">
          <Image
            src="/placeholder.svg?height=400&width=800"
            alt="Emporio Bianchi storico"
            width={800}
            height={400}
            className="w-full h-96 object-cover rounded-2xl shadow-lg"
          />
        </div>

        {/* Timeline */}
        <div className="mb-16">
          <h2 className="text-4xl font-bold text-center mb-12">Il Nostro Percorso</h2>

          <div className="space-y-12">
            {/* Fondazione */}
            <div className="flex flex-col md:flex-row items-center gap-8">
              <div className="md:w-1/2">
                <Card className="border-l-4 border-l-blue-600">
                  <CardHeader>
                    <div className="flex items-center gap-3">
                      <Clock className="w-6 h-6 text-blue-600" />
                      <CardTitle className="text-2xl">Le Origini</CardTitle>
                      <Badge variant="secondary">Tradizione</Badge>
                    </div>
                    <CardDescription className="text-lg">I primi anni di Emporio Bianchi</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-700 leading-relaxed">
                      Emporio Bianchi nasce come punto di riferimento storico a Cervia, costruendo nel tempo una solida
                      reputazione nel settore dei giochi e del collezionismo. Il nome "Bianchi" diventa sinonimo di
                      qualità e passione per generazioni di clienti.
                    </p>
                  </CardContent>
                </Card>
              </div>
              <div className="md:w-1/2">
                <Image
                  src="/placeholder.svg?height=300&width=400"
                  alt="Emporio Bianchi origini"
                  width={400}
                  height={300}
                  className="w-full h-64 object-cover rounded-lg shadow-md"
                />
              </div>
            </div>

            {/* Crescita */}
            <div className="flex flex-col md:flex-row-reverse items-center gap-8">
              <div className="md:w-1/2">
                <Card className="border-l-4 border-l-green-600">
                  <CardHeader>
                    <div className="flex items-center gap-3">
                      <Users className="w-6 h-6 text-green-600" />
                      <CardTitle className="text-2xl">Crescita e Riconoscimento</CardTitle>
                      <Badge variant="secondary">Espansione</Badge>
                    </div>
                    <CardDescription className="text-lg">
                      Diventando il punto di riferimento del territorio
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-700 leading-relaxed">
                      Nel corso degli anni, Emporio Bianchi si afferma come il negozio di riferimento per tutti gli
                      appassionati di giochi, carte TCG e collezionismo. La sua posizione strategica in Viale Sicilia 61
                      lo rende facilmente raggiungibile e molto frequentato.
                    </p>
                  </CardContent>
                </Card>
              </div>
              <div className="md:w-1/2">
                <Image
                  src="/placeholder.svg?height=300&width=400"
                  alt="Crescita del negozio"
                  width={400}
                  height={300}
                  className="w-full h-64 object-cover rounded-lg shadow-md"
                />
              </div>
            </div>

            {/* Nuova Gestione */}
            <div className="flex flex-col md:flex-row items-center gap-8">
              <div className="md:w-1/2">
                <Card className="border-l-4 border-l-purple-600">
                  <CardHeader>
                    <div className="flex items-center gap-3">
                      <Sparkles className="w-6 h-6 text-purple-600" />
                      <CardTitle className="text-2xl">Nuova Era</CardTitle>
                      <Badge variant="secondary">Innovazione</Badge>
                    </div>
                    <CardDescription className="text-lg">Diego Humberto Chaves e il futuro del negozio</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-700 leading-relaxed">
                      Oggi, sotto la nuova direzione di Diego Humberto Chaves, Emporio Bianchi continua ad evolversi
                      mantenendo intatta la sua identità storica. Il nome "Emporio Bianchi" è stato preservato per
                      onorare la lunga tradizione e la riconoscibilità sul territorio.
                    </p>
                  </CardContent>
                </Card>
              </div>
              <div className="md:w-1/2">
                <Image
                  src="/placeholder.svg?height=300&width=400"
                  alt="Nuova gestione"
                  width={400}
                  height={300}
                  className="w-full h-64 object-cover rounded-lg shadow-md"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Valori */}
        <section className="mb-16">
          <h2 className="text-4xl font-bold text-center mb-12">I Nostri Valori</h2>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Heart className="w-8 h-8 text-blue-600" />
                </div>
                <CardTitle className="text-xl">Passione</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Amiamo quello che facciamo e trasmettiamo questa passione a ogni cliente che entra nel nostro negozio.
                </p>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Award className="w-8 h-8 text-green-600" />
                </div>
                <CardTitle className="text-xl">Competenza</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Il nostro staff esperto è sempre pronto a consigliarti e aiutarti a trovare esattamente quello che
                  cerchi.
                </p>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Users className="w-8 h-8 text-purple-600" />
                </div>
                <CardTitle className="text-xl">Comunità</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Siamo più di un negozio: siamo un punto d'incontro per appassionati di tutte le età.
                </p>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Clock className="w-8 h-8 text-orange-600" />
                </div>
                <CardTitle className="text-xl">Tradizione</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Rispettiamo la nostra storia mentre guardiamo al futuro con innovazione e entusiasmo.
                </p>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Missione */}
        <section className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-2xl p-12 text-center">
          <h2 className="text-4xl font-bold mb-6">La Nostra Missione</h2>
          <p className="text-xl text-gray-700 max-w-4xl mx-auto leading-relaxed mb-8">
            Continuare a essere il punto di riferimento per tutti gli appassionati di giochi, carte TCG e collezionismo
            a Cervia e dintorni. Vogliamo offrire un'esperienza sempre più ricca, sia in negozio che online, mantenendo
            viva la tradizione di qualità e passione che ci contraddistingue da sempre.
          </p>
          <div className="flex items-center justify-center gap-2 text-lg font-semibold text-blue-600">
            <MapPin className="w-5 h-5" />
            <span>Viale Sicilia 61, Cervia - Dal cuore della città, per tutta la comunità</span>
          </div>
        </section>
      </div>
    </div>
  )
}
